/**
 * Pearl Authentication Module
 * Handles user signup, signin, and session management
 */

class PEARLAuth {
    constructor() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        const signupForm = document.querySelector('#signup-form');
        const signinForm = document.querySelector('#signin-form');
        const signoutBtn = document.querySelector('#signout-btn');

        if (signupForm) {
            signupForm.addEventListener('submit', (e) => this.handleSignup(e));
        }
        if (signinForm) {
            signinForm.addEventListener('submit', (e) => this.handleSignin(e));
        }
        if (signoutBtn) {
            signoutBtn.addEventListener('click', () => this.handleSignout());
        }
    }

    async handleSignup(event) {
        event.preventDefault();

        const username = document.querySelector('#signup-username').value;
        const email = document.querySelector('#signup-email').value;
        const password = document.querySelector('#signup-password').value;
        const confirmPassword = document.querySelector('#signup-confirm-password').value;

        if (password !== confirmPassword) {
            pearl.showError('Passwords do not match');
            return;
        }

        try {
            const response = await pearl.signUp(username, email, password);
            
            if (response.token && response.user) {
                pearl.setAuthToken(response.token, response.user);
                pearl.showSuccess('Account created! Redirecting to onboarding...');
                
                setTimeout(() => {
                    window.location.href = '/onboarding.html';
                }, 1500);
            }
        } catch (error) {
            pearl.showError(error.message || 'Signup failed. Please try again.');
        }
    }

    async handleSignin(event) {
        event.preventDefault();

        const email = document.querySelector('#signin-email').value;
        const password = document.querySelector('#signin-password').value;

        try {
            const response = await pearl.signIn(email, password);
            
            if (response.token && response.user) {
                pearl.setAuthToken(response.token, response.user);
                pearl.showSuccess('Signed in successfully!');
                
                setTimeout(() => {
                    window.location.href = '/index.html';
                }, 1500);
            }
        } catch (error) {
            pearl.showError(error.message || 'Login failed. Check your credentials.');
        }
    }

    async handleSignout() {
        try {
            await pearl.signOut();
            pearl.clearAuth();
            pearl.showSuccess('Signed out successfully');
            
            setTimeout(() => {
                window.location.href = '/login.html';
            }, 1000);
        } catch (error) {
            console.error('Signout error:', error);
            // Force clear auth anyway
            pearl.clearAuth();
            window.location.href = '/login.html';
        }
    }

    // Initialize auth on page load
    static initAuthPage() {
        new PEARLAuth();
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    PEARLAuth.initAuthPage();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PEARLAuth;
}
