/**
 * Pearl Frontend - Fully Functional Home Page
 * Integrated with Backend API
 */

// Auth State
let authToken = localStorage.getItem('auth_token');
let currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
const API_URL = window.location.hostname === 'localhost' ? 'http://localhost:8000' : window.location.origin;

// DOM Elements
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileMenuClose = document.querySelector('.mobile-menu-close');
const moduleCards = document.querySelectorAll('.module-card');
const applyButtons = document.querySelectorAll('.apply-btn');
const filterButtons = document.querySelectorAll('.filter-btn');
const moduleModal = document.querySelector('.module-modal');
const storyModal = document.querySelector('.story-modal');
const modalClose = document.querySelectorAll('.modal-close');
const storyClose = document.querySelector('.story-close');
const snackbar = document.querySelector('.snackbar');
const themeToggle = document.getElementById('themeToggle');
const mobileThemeToggle = document.getElementById('mobileThemeToggle');
const taikenPreview = document.querySelector('.taiken-preview');
const enterStoryBtn = document.getElementById('enterStoryBtn');
const continueBtn = document.getElementById('continueBtn');
const userMenu = document.querySelector('.user-menu');
const userDropdown = document.querySelector('.user-dropdown');

// ============================================
// API FUNCTIONS
// ============================================

async function apiCall(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (authToken && !options.skipAuth) {
        headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    const config = {
        method: options.method || 'GET',
        headers,
        ...options
    };
    
    if (options.body && typeof options.body === 'object') {
        config.body = JSON.stringify(options.body);
    }
    
    try {
        const response = await fetch(url, config);
        
        if (response.status === 401) {
            clearAuth();
            window.location.href = '/login.html';
            throw new Error('Session expired');
        }
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.detail || errorData.error || `HTTP ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error(`[API] Error:`, error);
        throw error;
    }
}

function clearAuth() {
    authToken = null;
    currentUser = null;
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
}

// ============================================
// MODULE DATA
// ============================================

const moduleData = {
    'web-fundamentals': {
        title: 'Web Fundamentals',
        description: 'Master HTML5, CSS3, and responsive design.',
        progress: 100,
        curriculum: [
            { title: 'HTML5 Semantic Elements', status: 'completed' },
            { title: 'CSS3 Styling & Layout', status: 'completed' },
            { title: 'Responsive Design', status: 'completed' }
        ]
    },
    'javascript-basics': {
        title: 'JavaScript Core',
        description: 'Learn JavaScript fundamentals and ES6+.',
        progress: 100,
        curriculum: [
            { title: 'Variables & Data Types', status: 'completed' },
            { title: 'Functions & Scope', status: 'completed' },
            { title: 'DOM Manipulation', status: 'completed' }
        ]
    },
    'react-mastery': {
        title: 'React Framework',
        description: 'Master React.js and build interactive applications.',
        progress: 0,
        curriculum: [
            { title: 'React Components', status: 'upcoming' },
            { title: 'React Hooks', status: 'upcoming' },
            { title: 'State Management', status: 'upcoming' }
        ]
    },
    'taiken-story': {
        title: 'Taiken Story Lab',
        description: 'Apply skills through immersive learning experiences.',
        progress: 45,
        currentStory: {
            title: 'The Startup Challenge',
            chapter: 'Chapter 2: The Bug Hunt',
            description: 'Debug production issues and implement fixes.',
            skills: ['Debugging', 'JavaScript', 'Problem Solving']
        }
    }
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    try {
        // Initialize UI components first (these should work even without auth)
        if (mobileMenuBtn && mobileMenu && mobileMenuClose) {
            initMobileMenu();
        }
        
        if (themeToggle) {
            initThemeToggle();
        }
        
        if (moduleCards.length > 0) {
            initModuleInteractions();
        }
        
        initFilters();
        initAnimations();
        initUserMenu();
        
        // Check auth but don't redirect immediately - allow UI to load
        if (!checkAuthStatus()) {
            // Not authenticated, but still show UI
            console.log('[AUTH] User not authenticated, showing public UI');
        } else {
            // User is authenticated, load dashboard
            loadDashboard();
        }
        
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark');
            if (themeToggle) themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    } catch (error) {
        console.error('[INIT] Error during initialization:', error);
    }
});

// Theme Toggle
function initThemeToggle() {
    if (!themeToggle) {
        console.warn('[INIT] Theme toggle not found');
        return;
    }
    
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark');
        if (document.body.classList.contains('dark')) {
            localStorage.setItem('theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            localStorage.setItem('theme', 'light');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
    });

    if (mobileThemeToggle) {
        mobileThemeToggle.addEventListener('change', () => {
            document.body.classList.toggle('dark');
            if (document.body.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
                if (themeToggle) themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                localStorage.setItem('theme', 'light');
                if (themeToggle) themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });
    }
}

// Mobile Menu
function initMobileMenu() {
    if (!mobileMenuBtn || !mobileMenu || !mobileMenuClose) {
        console.warn('[INIT] Mobile menu elements not found');
        return;
    }
    
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    mobileMenuClose.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (mobileMenu && mobileMenuBtn && !mobileMenu.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });

    // Close on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobileMenu && mobileMenu.classList.contains('active')) {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });
}

// Module Interactions
function initModuleInteractions() {
    if (!moduleCards || moduleCards.length === 0) {
        console.log('[INIT] No module cards found');
    } else {
        moduleCards.forEach(card => {
            if (!card.classList.contains('locked')) {
                card.addEventListener('click', (e) => {
                    const moduleId = card.getAttribute('data-module');
                    if (moduleId) {
                        // Check if it's a dynamic module (has session-id attribute)
                        const sessionId = card.getAttribute('data-session-id');
                        if (sessionId) {
                            // Dynamic module from backend
                            const skill = card.getAttribute('data-skill');
                            const moduleIdNum = parseInt(card.getAttribute('data-module-id'));
                            if (skill && moduleIdNum && typeof openModuleActions === 'function') {
                                openModuleActions(sessionId, skill, moduleIdNum);
                            }
                        } else if (moduleData[moduleId]) {
                            // Static module
                            if (moduleId === 'taiken-story' || moduleId === 'taiken-support' || moduleId === 'taiken-project') {
                                if (typeof openStoryModal === 'function') {
                                    openStoryModal(moduleId);
                                }
                            } else {
                                if (typeof openModuleModal === 'function') {
                                    openModuleModal(moduleId);
                                }
                            }
                        }
                    }
                });
            }
        });
    }

    // Modal close handlers
    if (modalClose && modalClose.length > 0) {
        modalClose.forEach(closeBtn => {
            closeBtn.addEventListener('click', () => {
                if (typeof closeModuleModal === 'function') closeModuleModal();
                if (typeof closeStoryModal === 'function') closeStoryModal();
            });
        });
    }
    
    if (storyClose) {
        storyClose.addEventListener('click', () => {
            if (typeof closeStoryModal === 'function') closeStoryModal();
        });
    }
    
    // Close modal when clicking outside
    if (moduleModal) {
        moduleModal.addEventListener('click', (e) => {
            if (e.target === moduleModal || e.target.classList.contains('modal-overlay')) {
                if (typeof closeModuleModal === 'function') closeModuleModal();
            }
        });
    }
    
    if (storyModal) {
        storyModal.addEventListener('click', (e) => {
            if (e.target === storyModal || e.target.classList.contains('modal-overlay')) {
                if (typeof closeStoryModal === 'function') closeStoryModal();
            }
        });
    }

    // Close on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (moduleModal && moduleModal.classList.contains('active')) {
                if (typeof closeModuleModal === 'function') closeModuleModal();
            }
            if (storyModal && storyModal.classList.contains('active')) {
                if (typeof closeStoryModal === 'function') closeStoryModal();
            }
        }
    });
}

function openModuleModal(moduleId) {
    if (!moduleModal) {
        console.warn('[MODAL] Module modal not found');
        return;
    }
    
    const data = moduleData[moduleId];
    if (!data) {
        console.warn(`[MODAL] No data for module: ${moduleId}`);
        return;
    }

    // Update modal content
    const modalTitle = document.getElementById('modalTitle');
    const modalDescription = document.getElementById('modalDescription');
    const modalProgress = document.getElementById('modalProgress');
    const modalProgressBar = document.getElementById('modalProgressBar');
    
    if (modalTitle) modalTitle.textContent = data.title;
    if (modalDescription) modalDescription.textContent = data.description;
    if (modalProgress) modalProgress.textContent = data.progress + '%';
    if (modalProgressBar) modalProgressBar.style.width = data.progress + '%';

    // Update curriculum
    const curriculumList = document.getElementById('modalCurriculum');
    if (curriculumList) {
        curriculumList.innerHTML = '';

        if (data.curriculum) {
            data.curriculum.forEach(item => {
                const statusClass = item.status === 'completed' ? 'completed' : 
                                   item.status === 'current' ? 'current' : 'upcoming';
                const icon = item.status === 'completed' ? 'fa-check' :
                            item.status === 'current' ? 'fa-spinner fa-spin' : 'fa-circle';

                const itemHTML = `
                    <div class="curriculum-item ${statusClass}">
                        <i class="fas ${icon}"></i>
                        <span>${item.title}</span>
                    </div>
                `;
                curriculumList.innerHTML += itemHTML;
            });
        }
    }

    // Set continue button action based on module status
    const continueBtn = document.getElementById('continueBtn');
    if (!continueBtn) {
        console.warn('[MODAL] Continue button not found');
        return;
    }
    if (data.progress === 0) {
        if (moduleId === 'react-mastery' || moduleId === 'state-management' || moduleId === 'ui-ux' || 
            moduleId === 'testing' || moduleId === 'performance') {
            continueBtn.innerHTML = '<i class="fas fa-lock"></i> Complete Taiken Story Lab First';
            continueBtn.onclick = () => {
                closeModuleModal();
                showNotification('Complete the Taiken Story Lab to unlock Frontend Development modules', 'info');
                // Scroll to Taiken section
                document.querySelector('[data-module="taiken-story"]').scrollIntoView({ behavior: 'smooth' });
            };
        } else {
            continueBtn.innerHTML = '<i class="fas fa-play"></i> Start Learning';
            continueBtn.onclick = () => {
                closeModuleModal();
                showNotification(`Starting ${data.title} module...`, 'success');
            };
        }
    } else if (data.progress === 100) {
        continueBtn.innerHTML = '<i class="fas fa-check"></i> Module Completed';
        continueBtn.onclick = () => {
            closeModuleModal();
            showNotification(`${data.title} already completed!`, 'info');
        };
    } else {
        continueBtn.innerHTML = '<i class="fas fa-play"></i> Continue Learning';
        continueBtn.onclick = () => {
            closeModuleModal();
            showNotification(`Continuing ${data.title} module...`, 'success');
        };
    }

    // Show modal
    if (moduleModal) {
        moduleModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModuleModal() {
    if (moduleModal) {
        moduleModal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

// Taiken Story Functions
function initTaikenStory() {
    if (taikenPreview) {
        taikenPreview.addEventListener('click', (e) => {
            e.stopPropagation();
            openStoryModal('taiken-story');
        });
    }
    
    if (enterStoryBtn) {
        enterStoryBtn.addEventListener('click', enterStoryLab);
    }
}

function openStoryModal(moduleId) {
    if (!storyModal) {
        console.warn('[MODAL] Story modal not found');
        return;
    }
    
    const data = moduleData[moduleId];
    if (!data) {
        console.warn(`[MODAL] No data for story: ${moduleId}`);
        return;
    }

    // Update story modal content
    const storyProgress = document.getElementById('storyProgress');
    const storyProgressBar = document.getElementById('storyProgressBar');
    
    if (storyProgress) storyProgress.textContent = data.progress + '%';
    if (storyProgressBar) storyProgressBar.style.width = data.progress + '%';

    // Update modal title and description based on module
    const modalTitle = document.querySelector('.story-header h3');
    const modalDescription = document.querySelector('.story-description p');
    
    if (modalTitle) modalTitle.textContent = data.title;
    if (modalDescription) modalDescription.textContent = data.description;

    if (moduleId === 'taiken-story') {
        // Show story-specific content
        document.querySelector('.current-story').style.display = 'block';
        document.querySelector('.story-achievements').style.display = 'block';
        document.querySelector('.story-benefits').style.display = 'block';
        
        // Update current story info if available
        if (data.currentStory) {
            const storyTitle = document.querySelector('.current-story h4');
            const scenarioTitle = document.querySelector('.scenario-header h5');
            const scenarioDesc = document.querySelector('.scenario-content p');
            const skillsContainer = document.querySelector('.scenario-skills');
            
            if (storyTitle) storyTitle.textContent = `Current Story: "${data.currentStory.title}"`;
            if (scenarioTitle) scenarioTitle.textContent = data.currentStory.chapter;
            if (scenarioDesc) scenarioDesc.innerHTML = `<strong>Scenario:</strong> ${data.currentStory.description}`;
            
            if (skillsContainer && data.currentStory.skills) {
                skillsContainer.innerHTML = '';
                data.currentStory.skills.forEach(skill => {
                    const skillTag = document.createElement('span');
                    skillTag.className = 'skill-tag small';
                    skillTag.textContent = skill;
                    skillsContainer.appendChild(skillTag);
                });
            }
        }

        // Update achievements if available
        if (data.achievements) {
            const achievementsGrid = document.querySelector('.achievements-grid');
            if (achievementsGrid) {
                achievementsGrid.innerHTML = '';
                data.achievements.forEach(achievement => {
                    const statusClass = achievement.status === 'completed' ? 'completed' : 
                                      achievement.status === 'current' ? 'current' : 'locked';
                    const icon = achievement.status === 'completed' ? 'fa-check-circle' :
                                achievement.status === 'current' ? 'fa-spinner fa-spin' : 'fa-lock';
                    
                    const achievementHTML = `
                        <div class="story-achievement ${statusClass}">
                            <i class="fas ${icon}"></i>
                            <div>
                                <strong>${achievement.title}</strong>
                                <small>${achievement.description}</small>
                            </div>
                        </div>
                    `;
                    achievementsGrid.innerHTML += achievementHTML;
                });
            }
        }
        
        // Update enter button
        enterStoryBtn.innerHTML = '<i class="fas fa-door-open"></i> Continue Story Journey';
        enterStoryBtn.onclick = enterStoryLab;
        
    } else if (moduleId === 'taiken-support') {
        // Show support-specific content
        document.querySelector('.current-story').style.display = 'none';
        document.querySelector('.story-achievements').style.display = 'none';
        document.querySelector('.story-benefits').style.display = 'none';
        
        // Update enter button for community
        enterStoryBtn.innerHTML = '<i class="fas fa-users"></i> Join Community';
        enterStoryBtn.onclick = () => {
            closeStoryModal();
            showNotification('Redirecting to Taiken Community...', 'success');
        };
        
    } else if (moduleId === 'taiken-project') {
        // Show project-specific content
        document.querySelector('.current-story').style.display = 'none';
        document.querySelector('.story-achievements').style.display = 'none';
        document.querySelector('.story-benefits').style.display = 'none';
        
        // Update enter button for project
        enterStoryBtn.innerHTML = '<i class="fas fa-lock"></i> Complete Story First';
        enterStoryBtn.onclick = () => {
            closeStoryModal();
            showNotification('Complete the Story Lab to unlock the Portfolio Project', 'info');
        };
    }

    // Show modal
    if (storyModal) {
        storyModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeStoryModal() {
    if (storyModal) {
        storyModal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

function enterStoryLab() {
    const data = moduleData['taiken-story'];
    showNotification(`Continuing ${data.currentStory.title} - ${data.currentStory.chapter}`, 'success');
    
    // Simulate loading animation
    const enterBtn = document.getElementById('enterStoryBtn');
    const originalHTML = enterBtn.innerHTML;
    enterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading Story Environment...';
    enterBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        enterBtn.innerHTML = originalHTML;
        enterBtn.disabled = false;
        closeStoryModal();
        
        // Show success message
        showNotification('Entered Story Lab environment. You can now work on the bug fix challenge.', 'success');
        
        // Update progress
        updateTaikenProgress(10);
        
        // Check if story is completed
        const currentProgress = data.progress + 10;
        if (currentProgress >= 100) {
            completeTaikenStory();
        }
    }, 2000);
}

function updateTaikenProgress(increment) {
    const progress = document.querySelector('.taiken-progress .progress-fill');
    const progressText = document.querySelector('.taiken-progress .progress-info span:last-child');
    const currentWidth = parseInt(progress.style.width);
    
    if (currentWidth < 100) {
        const newWidth = Math.min(currentWidth + increment, 100);
        progress.style.width = newWidth + '%';
        progressText.textContent = newWidth + '%';
        
        // Update module data
        moduleData['taiken-story'].progress = newWidth;
        
        // Update progress in modal if open
        document.getElementById('storyProgress').textContent = newWidth + '%';
        document.getElementById('storyProgressBar').style.width = newWidth + '%';
        
        showNotification(`Story progress updated to ${newWidth}%!`, 'success');
        
        // Check if we should unlock next chapter
        if (newWidth >= 25 && newWidth - increment < 25) {
            // Move to next chapter
            moduleData['taiken-story'].achievements[1].status = 'completed';
            moduleData['taiken-story'].achievements[2].status = 'current';
            moduleData['taiken-story'].currentStory.chapter = 'Chapter 3: The Feature Request';
            moduleData['taiken-story'].currentStory.description = 'The product team has requested a new feature. You need to implement it based on the specifications while maintaining code quality.';
            moduleData['taiken-story'].currentStory.skills = ['Feature Development', 'Code Review', 'Git Workflow'];
            
            showNotification('Congratulations! Chapter 2 completed. Starting Chapter 3: The Feature Request', 'success');
        }
    }
}

function completeTaikenStory() {
    // Update module status
    moduleData['taiken-story'].progress = 100;
    moduleData['taiken-story'].achievements[3].status = 'completed';
    
    // Unlock frontend development modules
    moduleData['react-mastery'].progress = 0;
    moduleData['state-management'].progress = 0;
    moduleData['ui-ux'].progress = 0;
    moduleData['testing'].progress = 0;
    moduleData['performance'].progress = 0;
    
    // Update UI
    const taikenCard = document.querySelector('[data-module="taiken-story"]');
    if (taikenCard) {
        taikenCard.classList.remove('current');
        taikenCard.classList.add('completed');
        const statusIcon = taikenCard.querySelector('.module-status i');
        if (statusIcon) {
            statusIcon.className = 'fas fa-check';
        }
    }
    
    // Update hero learning items
    const heroItems = document.querySelectorAll('.learning-item');
    if (heroItems[2]) {
        heroItems[2].classList.remove('active');
        heroItems[2].classList.add('completed');
        heroItems[2].innerHTML = '<i class="fas fa-check-circle"></i><span>Taiken Story Lab</span>';
        heroItems[3].classList.remove('locked');
        heroItems[3].classList.add('active');
        heroItems[3].innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>React Framework</span>';
    }
    
    // Unlock project module
    const projectCard = document.querySelector('[data-module="taiken-project"]');
    if (projectCard) {
        projectCard.classList.remove('locked');
        projectCard.classList.remove('upcoming');
        const statusIcon = projectCard.querySelector('.module-status i');
        if (statusIcon) {
            statusIcon.className = 'fas fa-circle';
        }
        const lockText = projectCard.querySelector('.module-meta span:last-child');
        if (lockText) {
            lockText.innerHTML = '<i class="fas fa-unlock"></i> Available';
        }
    }
    
    showNotification('🎉 Taiken Story Lab Completed! Frontend Development modules now unlocked.', 'success');
}

// Job Applications
function initJobApplications() {
    if (!applyButtons || applyButtons.length === 0) {
        // Jobs are loaded dynamically, buttons will be added later
        return;
    }
    
    applyButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const jobCard = this.closest('.job-card');
            if (jobCard) {
                const jobTitleEl = jobCard.querySelector('h3');
                const jobTitle = jobTitleEl ? jobTitleEl.textContent : 'Job';
                
                // Update button state
                this.innerHTML = '<i class="fas fa-check"></i> Applied';
                this.classList.remove('primary');
                this.disabled = true;
                
                // Show success message
                showNotification(`Application submitted for ${jobTitle}!`, 'success');
            }
        });
    });
}

// Filters
function initFilters() {
    if (!filterButtons || filterButtons.length === 0) {
        return;
    }
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.textContent;
            if (typeof filterJobs === 'function') {
                filterJobs(filter);
            }
        });
    });
}

function filterJobs(filter) {
    const jobCards = document.querySelectorAll('.job-card');
    
    jobCards.forEach(card => {
        let showCard = true;
        
        if (filter === 'Remote') {
            const location = card.querySelector('p').textContent;
            showCard = location.includes('Remote');
        } else if (filter === 'Full-time') {
            const type = card.querySelector('.job-meta').textContent;
            showCard = type.includes('Full-time');
        } else if (filter === 'High Match') {
            const matchScore = parseInt(card.querySelector('.match-badge').textContent);
            showCard = matchScore >= 90;
        }
        // 'All' shows all cards
        
        if (showCard) {
            card.style.display = 'block';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100);
        } else {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.display = 'none';
            }, 300);
        }
    });
}

// Animations
function initAnimations() {
    // Animate progress circles
    const progressCircles = document.querySelectorAll('.progress-circle');
    if (progressCircles.length > 0) {
        progressCircles.forEach(circle => {
            const progress = parseInt(circle.getAttribute('data-progress') || 0);
            const fill = circle.querySelector('.progress-fill');
            if (fill) {
                const radius = 45;
                const circumference = 2 * Math.PI * radius;
                
                fill.style.strokeDasharray = circumference;
                fill.style.strokeDashoffset = circumference - (progress / 100) * circumference;
            }
        });
    }
    
    // Animate activity chart bars
    const chartBars = document.querySelectorAll('.bar[data-value]');
    chartBars.forEach((bar, index) => {
        const value = bar.getAttribute('data-value');
        setTimeout(() => {
            bar.style.height = value + '%';
        }, index * 200);
    });
    
    // Animate skill distribution bars
    const skillBars = document.querySelectorAll('.skill-fill');
    skillBars.forEach((bar, index) => {
        setTimeout(() => {
            const width = bar.style.width;
            bar.style.transition = 'width 1s ease';
        }, index * 300);
    });
    
    // Add intersection observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.roadmap-level, .progress-card, .job-card, .module-card').forEach(el => {
        observer.observe(el);
    });
    
    // Animate module cards with staggered delay
    const allModuleCards = document.querySelectorAll('.module-card');
    allModuleCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Animate Taiken level circle
    const taikenCircle = document.querySelector('.taiken-level');
    if (taikenCircle) {
        setInterval(() => {
            taikenCircle.style.transform = taikenCircle.style.transform === 'scale(1.1)' ? 'scale(1)' : 'scale(1.1)';
        }, 1500);
    }
}

// Smooth Scrolling
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const offset = 80;
                const targetPosition = targetElement.offsetTop - offset;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                mobileMenu.classList.remove('active');
                document.body.style.overflow = 'auto';
            }
        });
    });
}

// Notifications
function showNotification(message, type = 'success') {
    // Try to use snackbar if available
    if (snackbar) {
        const snackbarContent = snackbar.querySelector('.snackbar-content');
        if (snackbarContent) {
            const icon = snackbarContent.querySelector('i');
            const span = snackbarContent.querySelector('span');
            
            // Update icon based on type
            if (icon) {
                if (type === 'success') {
                    icon.className = 'fas fa-check-circle';
                    snackbar.style.background = 'var(--success)';
                } else if (type === 'error') {
                    icon.className = 'fas fa-exclamation-circle';
                    snackbar.style.background = 'var(--danger)';
                } else {
                    icon.className = 'fas fa-info-circle';
                    snackbar.style.background = 'var(--primary)';
                }
            }
            
            if (span) span.textContent = message;
            snackbar.classList.add('show');
            
            setTimeout(() => {
                snackbar.classList.remove('show');
            }, 3000);
            return;
        }
    }
    
    // Fallback: use console
    console.log(`[${type.toUpperCase()}] ${message}`);
}
    
    // Hide after 3 seconds
    setTimeout(() => {
        snackbar.classList.remove('show');
    }, 3000);
}

// Initialize all animations and interactions
window.addEventListener('load', function() {
    // Ensure all modules are visible
    const modules = document.querySelectorAll('.module-card');
    modules.forEach(module => {
        module.style.opacity = '1';
        module.style.transform = 'translateY(0)';
    });
    
    // Add hover effects
    modules.forEach(module => {
        if (!module.classList.contains('locked')) {
            module.addEventListener('mouseenter', function() {
                if (!this.classList.contains('taiken-module')) {
                    this.style.transform = 'translateY(-8px)';
                } else {
                    this.style.transform = 'translateY(-8px) scale(1.02)';
                }
            });
            
            module.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                if (this.classList.contains('taiken-module')) {
                    this.style.transform = 'translateY(0) scale(1)';
                }
            });
        }
    });
    
    // Initialize progress animations
    const progressFills = document.querySelectorAll('.progress-fill');
    progressFills.forEach(fill => {
        const width = fill.style.width;
        fill.style.width = '0%';
        setTimeout(() => {
            fill.style.width = width;
        }, 500);
    });
});

// Add CSS animation for staggered module cards
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .module-card {
        animation: fadeInUp 0.6s ease forwards;
        opacity: 0;
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    @keyframes pulse {
        0%, 100% { 
            box-shadow: 0 0 0 4px rgba(123, 31, 162, 0.2);
        }
        50% { 
            box-shadow: 0 0 0 8px rgba(123, 31, 162, 0.2);
        }
    }
    
    .taiken-level {
        animation: pulse 2s infinite;
    }
`;
document.head.appendChild(style);

// ============================================
// AUTH FUNCTIONS
// ============================================

function checkAuthStatus() {
    // Check if user is authenticated
    if (!authToken || !currentUser || !currentUser.id) {
        // Don't redirect immediately - allow UI to show
        // User can still see the page, just won't load personalized data
        console.log('[AUTH] Not authenticated');
        return false;
    }
    return true;
}

function initUserMenu() {
    if (!userMenu) return;
    
    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        if (userDropdown) {
            userDropdown.classList.toggle('active');
        }
    });
    
    // Update user info in navbar
    const userNameEl = document.querySelector('.user-name');
    if (userNameEl && currentUser.username) {
        userNameEl.textContent = currentUser.username;
    }
    
    // Update user avatar with profile picture
    updateUserAvatar();
    
    // Add logout option to dropdown
    if (userDropdown && !userDropdown.querySelector('.logout-option')) {
        const logoutBtn = document.createElement('div');
        logoutBtn.className = 'logout-option';
        logoutBtn.innerHTML = `
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        `;
        logoutBtn.addEventListener('click', signOut);
        userDropdown.appendChild(logoutBtn);
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!userMenu.contains(e.target) && userDropdown) {
            userDropdown.classList.remove('active');
        }
    });
}

function updateUserAvatar() {
    const avatarElements = document.querySelectorAll('.user-avatar, .mobile-avatar');
    avatarElements.forEach(avatar => {
        if (currentUser.profile_pic_url) {
            avatar.src = currentUser.profile_pic_url;
        } else if (currentUser.email) {
            // Fallback to generated avatar based on email
            avatar.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.email}`;
        }
    });
}

function signOut(event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    
    clearAuth();
    showNotification('Signed out successfully', 'success');
    setTimeout(() => {
        window.location.href = '/login.html';
    }, 1000);
}

// ============================================
// DASHBOARD FUNCTIONS
// ============================================

async function loadDashboard() {
    try {
        // Check if user is authenticated
        if (!currentUser || !currentUser.id) {
            console.log('[DASHBOARD] User not authenticated, skipping dashboard load');
            // Show placeholder or login prompt
            showLoginPrompt();
            return;
        }
        
        console.log('[DASHBOARD] Loading dashboard data...');
        
        // Load user profile with full data
        const profileData = await apiCall(`/auth/profile/${currentUser.id}`).catch(() => null);
        
        if (profileData) {
            // Update current user with profile data
            currentUser = {
                ...currentUser,
                ...profileData.profile,
                skills: profileData.skills || [],
                profile_pic_url: profileData.profile?.profile_pic_url
            };
            localStorage.setItem('user_data', JSON.stringify(currentUser));
            
            // Update avatar
            if (typeof updateUserAvatar === 'function') {
                updateUserAvatar();
            }
        }
        
        // Load quick stats in parallel
        const [points, skills, onboarding] = await Promise.all([
            apiCall(`/api/user/${currentUser.id}/points`).catch(() => ({ total: 0, streak: 0, rank_level: 'beginner' })),
            apiCall(`/api/user/${currentUser.id}/skills`).catch(() => []),
            getOnboardingData()
        ]);
        
        console.log('[DASHBOARD] Loaded data:', { points, skillsCount: skills.length, hasOnboarding: !!onboarding });
        
        // Load jobs with proper parameters
        const jobsResponse = await loadJobRecommendations();
        const jobsData = jobsResponse?.jobs || [];
        
        updateDashboardStats(points, skills.length);
        displayJobs(jobsData);
        
        // Load and display learning paths if session exists
        const sessionId = localStorage.getItem('current_session_id');
        if (sessionId) {
            await loadLearningPaths(sessionId);
            
            // Update button text
            const btnText = document.getElementById('journeyButtonText');
            if (btnText) btnText.textContent = 'Continue Learning';
        } else if (onboarding && onboarding.target_role) {
            // Show button to start journey
            const btnText = document.getElementById('journeyButtonText');
            if (btnText) btnText.textContent = 'Start Learning Journey';
        }
        
        // Generate roadmap for current module (Taiken Story Lab)
        await generateCurrentModuleRoadmap(onboarding, skills);
        
    } catch (error) {
        console.error('[DASHBOARD] Error loading dashboard:', error);
        // Don't break the UI, just log the error
    }
}

// Show login prompt if not authenticated
function showLoginPrompt() {
    const heroActions = document.querySelector('.hero-actions');
    if (heroActions) {
        const existingBtn = heroActions.querySelector('button');
        if (existingBtn) {
            existingBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In to Start';
            existingBtn.onclick = () => {
                window.location.href = '/login.html';
            };
        }
    }
}

// Load learning paths from session
async function loadLearningPaths(sessionId) {
    try {
        const sessionData = await apiCall(`/api/learning/session/${sessionId}`).catch(() => null);
        
        if (sessionData && sessionData.session) {
            const jd_parsed = sessionData.session.jd_parsed || {};
            const learning_paths = jd_parsed.learning_paths || {};
            
            if (Object.keys(learning_paths).length > 0) {
                displayLearningPaths(learning_paths);
            }
        }
    } catch (error) {
        console.error('[DASHBOARD] Error loading learning paths:', error);
    }
}

// Auto-start journey if onboarding is complete
async function autoStartJourney(onboarding) {
    try {
        const goal = onboarding.target_role || onboarding.primary_career_goal;
        if (!goal) return;
        
        console.log('[DASHBOARD] Auto-starting journey for:', goal);
        
        const response = await apiCall('/agent/start-journey', {
            method: 'POST',
            body: {
                goal: goal,
                user_id: currentUser.id,
                jd_text: null
            }
        });
        
        if (response.session_id) {
            localStorage.setItem('current_session_id', response.session_id);
            localStorage.setItem('target_role', response.target_role);
            
            // Display the learning paths
            if (response.learning_paths) {
                displayLearningPaths(response.learning_paths);
            }
        }
    } catch (error) {
        console.error('[DASHBOARD] Auto-start journey error:', error);
    }
}

// Display learning paths in roadmap section
function displayLearningPaths(learning_paths) {
    try {
        const roadmapSection = document.querySelector('.roadmap-section .vertical-roadmap');
        if (!roadmapSection) return;
        
        // Clear existing content
        roadmapSection.innerHTML = '';
        
        const sessionId = localStorage.getItem('current_session_id');
        
        // Group by skill
        Object.entries(learning_paths).forEach(([skill, path], skillIndex) => {
            const levelHTML = `
                <div class="roadmap-level">
                    <div class="level-header">
                        <div class="level-indicator">
                            <div class="level-circle">${skillIndex + 1}</div>
                            <div class="level-line"></div>
                        </div>
                        <div class="level-content">
                            <h3 class="level-title">${skill}</h3>
                            <p class="level-description">${path.description || 'Learning path for ' + skill}</p>
                        </div>
                    </div>
                    
                    <div class="modules-grid">
                        ${path.modules?.map((module, moduleIndex) => {
                            const isActive = module.status === 'active';
                            const isCompleted = module.status === 'completed';
                            const isLocked = module.status === 'locked';
                            const actionsCount = module.actions?.length || 0;
                            const completedActions = module.actions?.filter(a => a.completed).length || 0;
                            const progressPercent = actionsCount > 0 ? Math.round((completedActions / actionsCount) * 100) : 0;
                            
                            // Check if this is a Taiken module (has taiken action)
                            const hasTaiken = module.actions?.some(a => a.type === 'taiken');
                            const moduleClass = hasTaiken ? 'taiken-module' : '';
                            
                            return `
                            <div class="module-card ${moduleClass} ${isCompleted ? 'completed' : isActive ? 'current' : 'upcoming'}" 
                                 data-module="${skill}-${module.module_id}"
                                 data-skill="${skill}"
                                 data-module-id="${module.module_id}"
                                 data-session-id="${sessionId}"
                                 ${!isLocked ? 'onclick="openModuleActions(\'' + sessionId + '\', \'' + skill + '\', ' + module.module_id + ')"' : ''}
                                 style="cursor: ${isLocked ? 'not-allowed' : 'pointer'}">
                                <div class="module-status ${module.status}">
                                    <i class="fas ${isCompleted ? 'fa-check' : isActive ? 'fa-spinner fa-spin' : 'fa-lock'}"></i>
                                </div>
                                <div class="module-content">
                                    <div class="module-icon ${hasTaiken ? 'taiken' : ''}">
                                        <i class="fas ${hasTaiken ? 'fa-book-open' : 'fa-book'}"></i>
                                    </div>
                                    <div>
                                        <h4>${module.name || `Module ${module.module_id}`}</h4>
                                        <p>${module.description || 'Learning module'}</p>
                                        <div class="module-meta">
                                            <span><i class="fas fa-tasks"></i> ${actionsCount} Actions</span>
                                            <span><i class="fas fa-check-circle"></i> ${completedActions}/${actionsCount}</span>
                                        </div>
                                        ${!isLocked ? `
                                            <div class="module-progress-bar">
                                                <div class="progress-bar-small">
                                                    <div class="progress-fill" style="width: ${progressPercent}%"></div>
                                                </div>
                                                <span class="progress-text">${progressPercent}%</span>
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        `;
                        }).join('') || ''}
                    </div>
                </div>
            `;
            
            roadmapSection.insertAdjacentHTML('beforeend', levelHTML);
        });
        
        // Add click handlers for module cards
        attachModuleClickHandlers();
        
    } catch (error) {
        console.error('[DASHBOARD] Display learning paths error:', error);
    }
}

// Open module actions modal
async function openModuleActions(sessionId, skill, moduleId) {
    try {
        // Get module data from session
        const sessionData = await apiCall(`/api/learning/session/${sessionId}`);
        const learning_paths = sessionData.session?.jd_parsed?.learning_paths || {};
        const learning_path = learning_paths[skill];
        
        if (!learning_path) {
            throw new Error('Learning path not found');
        }
        
        const module = learning_path.modules.find(m => m.module_id === moduleId);
        if (!module) {
            throw new Error('Module not found');
        }
        
        // Display module actions using the module-actions.js handler
        if (typeof window.displayModuleActions === 'function') {
            await window.displayModuleActions(sessionId, skill, moduleId, module);
        } else {
            // Fallback: show basic module info
            showNotification(`Module: ${module.name}`, 'info');
        }
        
    } catch (error) {
        console.error('[MODULE] Open error:', error);
        showNotification('Failed to load module', 'error');
    }
}

// Attach click handlers to module cards
function attachModuleClickHandlers() {
    const moduleCards = document.querySelectorAll('.module-card[data-session-id]');
    moduleCards.forEach(card => {
        card.addEventListener('click', function(e) {
            if (this.classList.contains('upcoming') && !this.classList.contains('current')) {
                return; // Don't open locked modules
            }
            
            const sessionId = this.getAttribute('data-session-id');
            const skill = this.getAttribute('data-skill');
            const moduleId = parseInt(this.getAttribute('data-module-id'));
            
            if (sessionId && skill && moduleId) {
                openModuleActions(sessionId, skill, moduleId);
            }
        });
    });
}

// Make function globally available
window.openModuleActions = openModuleActions;

async function loadJobRecommendations() {
    try {
        if (!currentUser || !currentUser.id) {
            return { success: false, jobs: [] };
        }
        
        // Get target role from onboarding data or use default
        const targetRole = currentUser.target_role || localStorage.getItem('target_role') || 'Software Developer';
        const location = currentUser.location || localStorage.getItem('location') || 'Chennai';
        
        const params = new URLSearchParams({
            user_id: currentUser.id,
            target_role: targetRole,
            location: location
        });
        
        const response = await apiCall(`/agent/jobs/recommendations?${params.toString()}`).catch(err => {
            console.error('[JOBS] Failed to load recommendations:', err);
            return { success: false, jobs: [] };
        });
        
        console.log('[JOBS] Loaded recommendations:', response);
        return response;
        
    } catch (error) {
        console.error('[JOBS] Error loading recommendations:', error);
        return { success: false, jobs: [] };
    }
}

async function getOnboardingData() {
    try {
        if (!currentUser || !currentUser.id) {
            return null;
        }
        
        const data = await apiCall(`/agent/onboarding/${currentUser.id}`).catch(() => null);
        
        if (data && data.success) {
            return {
                primary_career_goal: data.primary_career_goal,
                target_role: data.target_role,
                learning_preference: data.learning_preference,
                time_availability: data.time_availability,
                current_status: data.current_status,
                skills: data.skills || []
            };
        }
        
        return data;
    } catch (error) {
        console.error('Error loading onboarding data:', error);
        return null;
    }
}

async function generateCurrentModuleRoadmap(onboarding, userSkills) {
    try {
        if (!onboarding || !onboarding.primary_career_goal) {
            console.log('[ROADMAP] No onboarding data, skipping roadmap generation');
            return;
        }
        
        // Extract skills from current skills list
        const skillNames = userSkills.map(s => s.skill_name || s.skill || s).filter(Boolean);
        
        console.log(`[ROADMAP] Generating roadmap for current module with skills: ${skillNames.join(", ")}`);
        
        // Generate roadmap for the main target role/goal
        const targetRole = onboarding.target_role || onboarding.primary_career_goal;
        const learningPreference = onboarding.learning_preference || 'mixed';
        
        const roadmapResponse = await apiCall('/agent/learning-roadmap/' + encodeURIComponent(targetRole), {
            method: 'GET',
            headers: {
                'learning-preference': learningPreference
            }
        }).catch(error => {
            console.error('[ROADMAP] Error generating roadmap:', error);
            return null;
        });
        
        if (roadmapResponse && roadmapResponse.roadmap) {
            displayCurrentModuleRoadmap(roadmapResponse.roadmap);
        }
        
    } catch (error) {
        console.error('Error generating roadmap:', error);
    }
}

function displayCurrentModuleRoadmap(roadmap) {
    try {
        const roadmapContainer = document.querySelector('.roadmap-section');
        if (!roadmapContainer) return;
        
        // Only show first module as "current"
        const currentPhase = roadmap.phases?.[0];
        if (!currentPhase) return;
        
        let roadmapHTML = '<div class="roadmap-content">';
        
        // Display current phase
        roadmapHTML += `
            <div class="roadmap-phase active">
                <h3>📚 Current Learning Path</h3>
                <div class="phase-header">
                    <span class="phase-label">${currentPhase.name || 'Phase 1'}</span>
                    <span class="phase-duration">${currentPhase.duration || '2-3 weeks'}</span>
                </div>
                <div class="phase-description">
                    ${currentPhase.description || 'Master the foundational concepts for this module'}
                </div>
                
                <div class="topics-list">
                    ${(currentPhase.topics || [])
                        .slice(0, 5)
                        .map((topic, idx) => `
                            <div class="topic-item">
                                <span class="topic-number">${idx + 1}</span>
                                <span class="topic-name">${topic.name || topic}</span>
                                <span class="topic-duration">${topic.estimated_hours || '2'}h</span>
                            </div>
                        `)
                        .join('')
                    }
                </div>
                
                <button class="btn primary" onclick="startCurrentModule()">
                    <i class="fas fa-play"></i>
                    Start This Module
                </button>
            </div>
        `;
        
        // Show upcoming modules preview
        if (roadmap.phases && roadmap.phases.length > 1) {
            roadmapHTML += '<div class="upcoming-modules">';
            roadmapHTML += '<p style="color: #999; font-size: 0.9em; margin-bottom: 10px;">📌 Complete current module to unlock next ones</p>';
            
            roadmap.phases.slice(1, 4).forEach((phase, idx) => {
                roadmapHTML += `
                    <div class="upcoming-module locked">
                        <i class="fas fa-lock"></i>
                        <div>
                            <h4>${phase.name || 'Phase ' + (idx + 2)}</h4>
                            <small>${phase.duration || 'TBA'}</small>
                        </div>
                    </div>
                `;
            });
            
            roadmapHTML += '</div>';
        }
        
        roadmapHTML += '</div>';
        
        // Insert or update roadmap
        const existingRoadmap = roadmapContainer.querySelector('.roadmap-content');
        if (existingRoadmap) {
            existingRoadmap.replaceWith(roadmapHTML);
        } else {
            roadmapContainer.innerHTML = roadmapHTML;
        }
        
    } catch (error) {
        console.error('[ROADMAP] Display error:', error);
    }
}

function startCurrentModule() {
    // Find and open current module (Taiken Story Lab)
    const taikenCard = document.querySelector('[data-module="taiken-story"]');
    if (taikenCard) {
        taikenCard.click();
    } else {
        showNotification('Start with the Taiken Story Lab module', 'info');
    }
}

// Start or continue learning journey
async function startOrContinueJourney() {
    try {
        const sessionId = localStorage.getItem('current_session_id');
        
        if (sessionId) {
            // Continue existing journey
            const sessionData = await apiCall(`/api/learning/session/${sessionId}`).catch(() => null);
            
            if (sessionData && sessionData.session) {
                // Scroll to roadmap
                document.querySelector('#roadmap')?.scrollIntoView({ behavior: 'smooth' });
                showNotification('Continuing your learning journey', 'info');
            } else {
                // Session not found, start new
                await startNewJourney();
            }
        } else {
            // Start new journey
            await startNewJourney();
        }
    } catch (error) {
        console.error('[JOURNEY] Error:', error);
        showNotification('Failed to start journey. Please try again.', 'error');
    }
}

// Start a new learning journey
async function startNewJourney() {
    try {
        // Get onboarding data or prompt user
        const onboarding = await getOnboardingData();
        const goal = onboarding?.target_role || onboarding?.primary_career_goal;
        
        if (!goal) {
            // Prompt user for career goal
            const userGoal = prompt('Enter your career goal (e.g., "Become a Backend Developer"):');
            if (!userGoal) return;
            
            // Start journey with user input
            const response = await apiCall('/agent/start-journey', {
                method: 'POST',
                body: {
                    goal: userGoal,
                    user_id: currentUser.id,
                    jd_text: null
                }
            });
            
            if (response.session_id) {
                localStorage.setItem('current_session_id', response.session_id);
                localStorage.setItem('target_role', response.target_role);
                
                // Display learning paths
                if (response.learning_paths) {
                    displayLearningPaths(response.learning_paths);
                }
                
                // Update button text
                const btnText = document.getElementById('journeyButtonText');
                if (btnText) btnText.textContent = 'Continue Learning';
                
                // Scroll to roadmap
                document.querySelector('#roadmap')?.scrollIntoView({ behavior: 'smooth' });
                showNotification('Learning journey started!', 'success');
            }
        } else {
            // Use onboarding goal
            const response = await apiCall('/agent/start-journey', {
                method: 'POST',
                body: {
                    goal: goal,
                    user_id: currentUser.id,
                    jd_text: null
                }
            });
            
            if (response.session_id) {
                localStorage.setItem('current_session_id', response.session_id);
                localStorage.setItem('target_role', response.target_role);
                
                // Display learning paths
                if (response.learning_paths) {
                    displayLearningPaths(response.learning_paths);
                }
                
                // Update button text
                const btnText = document.getElementById('journeyButtonText');
                if (btnText) btnText.textContent = 'Continue Learning';
                
                // Scroll to roadmap
                document.querySelector('#roadmap')?.scrollIntoView({ behavior: 'smooth' });
                showNotification('Learning journey started!', 'success');
            }
        }
    } catch (error) {
        console.error('[JOURNEY] Start error:', error);
        showNotification('Failed to start journey: ' + (error.message || 'Unknown error'), 'error');
    }
}

// Make functions globally available
// Make functions globally available
window.startOrContinueJourney = startOrContinueJourney;
window.openModuleActions = openModuleActions;
window.showNotification = showNotification;
window.openModuleModal = openModuleModal;
window.closeModuleModal = closeModuleModal;
window.openStoryModal = openStoryModal;
window.closeStoryModal = closeStoryModal;
window.enterStoryLab = enterStoryLab;
window.applyForJob = applyForJob;
window.openModuleActions = openModuleActions;
window.startAction = typeof startAction !== 'undefined' ? startAction : null;
window.completeAction = typeof completeAction !== 'undefined' ? completeAction : null;
window.submitCheckpoint = typeof submitCheckpoint !== 'undefined' ? submitCheckpoint : null;
window.showNotification = showNotification;
window.openModuleModal = openModuleModal;
window.closeModuleModal = closeModuleModal;
window.openStoryModal = openStoryModal;
window.closeStoryModal = closeStoryModal;
window.enterStoryLab = enterStoryLab;

function updateDashboardStats(points, skillCount) {
    // Try multiple selectors for stats
    const pointsEl = document.querySelector('.quick-stat:nth-child(1) .stat-value') || 
                     document.querySelector('.stat-number');
    const skillsEl = document.querySelector('.quick-stat:nth-child(2) .stat-value') ||
                     document.querySelectorAll('.stat-number')[1];
    
    if (pointsEl) {
        pointsEl.textContent = points?.total || points?.points || 0;
    }
    if (skillsEl) {
        skillsEl.textContent = skillCount || 0;
    }
}

async function displayJobs(jobs) {
    if (!jobs || jobs.length === 0) {
        displayEmptyJobsState();
        return;
    }
    
    const jobsContainer = document.querySelector('.jobs-grid');
    if (!jobsContainer) return;
    
    jobsContainer.innerHTML = jobs.map((job, idx) => {
        // Handle both Adzuna API format and custom format
        const matchPercentage = job.match_percentage || job.match_score || 85;
        const matchedSkills = job.matched_skills || job.skills || [];
        const jobId = job.id || job.job_id || `job-${idx}`;
        const jobUrl = job.url || job.job_url || '#';
        
        return `
            <div class="job-card" data-job-id="${jobId}">
                <div class="job-header">
                    <div class="job-title-section">
                        <h3>${job.title || 'Job Title'}</h3>
                        <span class="match-badge ${matchPercentage >= 90 ? 'high' : matchPercentage >= 70 ? 'medium' : 'low'}">
                            ${Math.round(matchPercentage)}% Match
                        </span>
                    </div>
                </div>
                
                <p class="company">
                    <i class="fas fa-building"></i>
                    ${job.company || 'Company Name'}
                </p>
                
                <p class="location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${job.location || job.place || 'Location'}
                </p>
                
                <div class="job-meta">
                    <span class="job-type">
                        <i class="fas fa-briefcase"></i>
                        ${job.type || job.contract_type || 'Full-time'}
                    </span>
                    ${job.salary ? `<span class="job-salary"><i class="fas fa-dollar-sign"></i> ${job.salary}</span>` : ''}
                </div>
                
                ${matchedSkills.length > 0 ? `
                    <div class="matched-skills">
                        <small style="color: #666;">Your skills:</small>
                        <div class="skills-tags">
                            ${matchedSkills.slice(0, 3).map(skill => 
                                `<span class="skill-tag">${skill}</span>`
                            ).join('')}
                            ${matchedSkills.length > 3 ? `<span class="skill-tag more">+${matchedSkills.length - 3}</span>` : ''}
                        </div>
                    </div>
                ` : ''}
                
                <div class="job-actions">
                    <a href="${jobUrl}" target="_blank" class="btn outline" ${jobUrl === '#' ? 'style="pointer-events:none;opacity:0.5;"' : ''}>
                        <i class="fas fa-external-link-alt"></i>
                        View Job
                    </a>
                    <button class="apply-btn primary" onclick="applyForJob('${jobId}', '${(job.title || 'Job').replace(/'/g, "\\'")}')" 
                            data-job-title="${(job.title || 'Job').replace(/"/g, '&quot;')}">
                        <i class="fas fa-check"></i>
                        Apply
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function displayEmptyJobsState() {
    const jobsContainer = document.querySelector('.jobs-grid');
    if (!jobsContainer) return;
    
    jobsContainer.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #999;">
            <i class="fas fa-briefcase" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
            <p>No jobs matching your profile yet</p>
            <small>Complete more modules to unlock better job recommendations</small>
        </div>
    `;
}

async function applyForJob(jobId, jobTitle) {
    try {
        const btn = event.target.closest('.apply-btn');
        if (!btn) return;
        
        btn.disabled = true;
        const originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Applying...';
        
        // Track the application in analytics
        await apiCall('/api/analytics/track', {
            method: 'POST',
            body: { 
                event_type: 'job_applied', 
                job_id: jobId,
                job_title: jobTitle,
                timestamp: new Date().toISOString()
            }
        }).catch(err => {
            console.error('[ANALYTICS] Failed to track job application:', err);
            // Continue even if tracking fails
        });
        
        btn.innerHTML = '<i class="fas fa-check"></i> Applied';
        btn.disabled = false;
        
        showNotification(`✅ Applied for ${jobTitle}!`, 'success');
        
        // Mark button as applied
        btn.closest('.job-card')?.classList.add('applied');
        
    } catch (error) {
        console.error('[JOBS] Apply error:', error);
        showNotification('Failed to apply for job. Please try again.', 'error');
        const btn = event.target.closest('.apply-btn');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-arrow-right"></i> Apply';
        }
    }
}