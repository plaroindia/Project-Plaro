/**
 * Pearl Dashboard Module
 * Displays all main features: jobs, learning paths, gamification, content
 */

class PEARLDashboard {
    constructor() {
        this.currentUser = pearl.getCurrentUser();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Tab navigation
        const tabs = document.querySelectorAll('[data-tab]');
        tabs.forEach(tab => {
            tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });

        // Refresh buttons
        document.querySelector('#refresh-jobs')?.addEventListener('click', () => this.loadJobs());
        document.querySelector('#refresh-learning')?.addEventListener('click', () => this.loadLearningPaths());
        document.querySelector('#refresh-gamification')?.addEventListener('click', () => this.loadGamification());

        // Profile button
        document.querySelector('#profile-btn')?.addEventListener('click', () => {
            window.location.href = '/profile.html';
        });
    }

    switchTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('[data-tab-content]').forEach(tab => {
            tab.style.display = 'none';
        });

        // Show selected tab
        const selectedTab = document.querySelector(`[data-tab-content="${tabName}"]`);
        if (selectedTab) {
            selectedTab.style.display = 'block';

            // Load content if empty
            if (selectedTab.innerHTML.trim() === '') {
                this.loadTabContent(tabName);
            }
        }

        // Update active tab indicator
        document.querySelectorAll('[data-tab]').forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.tab === tabName) {
                tab.classList.add('active');
            }
        });
    }

    loadTabContent(tabName) {
        switch (tabName) {
            case 'jobs':
                this.loadJobs();
                break;
            case 'learning':
                this.loadLearningPaths();
                break;
            case 'gamification':
                this.loadGamification();
                break;
            case 'content':
                this.loadContent();
                break;
        }
    }

    // ============================================
    // JOBS SECTION
    // ============================================

    async loadJobs() {
        const container = document.querySelector('[data-tab-content="jobs"]');
        container.innerHTML = '<div class="loading">Loading jobs...</div>';

        try {
            const jobs = await pearl.getJobRecommendations(
                this.currentUser.id,
                this.currentUser.targetRole || 'Any',
                this.currentUser.location || 'Remote'
            );

            container.innerHTML = this.renderJobsList(jobs);
        } catch (error) {
            container.innerHTML = `<div class="error">Failed to load jobs: ${error.message}</div>`;
        }
    }

    renderJobsList(jobs) {
        if (!jobs || jobs.length === 0) {
            return '<p>No job recommendations available yet.</p>';
        }

        return `
            <div class="jobs-grid">
                ${jobs.map(job => `
                    <div class="job-card">
                        <h3>${job.title || 'Job Title'}</h3>
                        <p class="company">${job.company || 'Company'}</p>
                        <p class="location">${job.location || 'Location'}</p>
                        <p class="description">${(job.description || '').substring(0, 150)}...</p>
                        <div class="job-meta">
                            <span class="job-type">${job.type || 'Full-time'}</span>
                            <span class="salary">${job.salary || 'Competitive'}</span>
                        </div>
                        <button class="btn-primary" onclick="window.open('${job.url}', '_blank')">
                            View Job
                        </button>
                        <button class="btn-secondary" onclick="savejob('${job.id}')">
                            Save
                        </button>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // ============================================
    // LEARNING PATHS SECTION
    // ============================================

    async loadLearningPaths() {
        const container = document.querySelector('[data-tab-content="learning"]');
        container.innerHTML = '<div class="loading">Loading learning paths...</div>';

        try {
            const paths = await this.generateLearningPath();
            container.innerHTML = this.renderLearningPaths(paths);
        } catch (error) {
            container.innerHTML = `
                <div class="error">Failed to load learning paths: ${error.message}</div>
                <button class="btn-primary" onclick="dashboard.generateNewPath()">Generate New Path</button>
            `;
        }
    }

    async generateLearningPath() {
        const targetRole = this.currentUser.targetRole || 'Full Stack Developer';
        const skills = await pearl.getUserSkills(this.currentUser.id);

        return await pearl.generateLearningPath(
            targetRole,
            skills.map(s => s.name)
        );
    }

    renderLearningPaths(pathData) {
        if (!pathData || !pathData.modules || pathData.modules.length === 0) {
            return '<p>No learning paths available. Generate one to get started!</p>';
        }

        return `
            <div class="learning-overview">
                <div class="path-progress">
                    <h3>${pathData.title || 'Your Learning Path'}</h3>
                    <p class="description">${pathData.description || ''}</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${pathData.progress || 0}%"></div>
                    </div>
                </div>
            </div>
            <div class="modules-grid">
                ${pathData.modules.map((module, index) => `
                    <div class="module-card ${module.completed ? 'completed' : ''}">
                        <div class="module-number">${index + 1}</div>
                        <h4>${module.title}</h4>
                        <p class="module-description">${module.description}</p>
                        <div class="module-stats">
                            <span class="duration">${module.duration} hours</span>
                            <span class="difficulty">${module.difficulty}</span>
                        </div>
                        ${!module.completed ? `
                            <button class="btn-primary" onclick="dashboard.startModule('${module.id}')">
                                Start Module
                            </button>
                        ` : `
                            <span class="badge-completed">Completed</span>
                        `}
                    </div>
                `).join('')}
            </div>
        `;
    }

    async startModule(moduleId) {
        try {
            const session = await pearl.getSession(this.currentUser.id);
            const module = await pearl.getModule(session.id, moduleId);
            
            // Redirect to learning view or open modal
            window.location.href = `/learning.html?module=${moduleId}&session=${session.id}`;
        } catch (error) {
            pearl.showError('Failed to start module: ' + error.message);
        }
    }

    // ============================================
    // GAMIFICATION SECTION
    // ============================================

    async loadGamification() {
        const container = document.querySelector('[data-tab-content="gamification"]');
        container.innerHTML = '<div class="loading">Loading gamification data...</div>';

        try {
            const points = await pearl.getUserPoints(this.currentUser.id);
            const leaderboard = await pearl.getLeaderboard(5);
            const achievements = await pearl.getAchievements(this.currentUser.id);

            container.innerHTML = this.renderGamification(points, leaderboard, achievements);
        } catch (error) {
            container.innerHTML = `<div class="error">Failed to load gamification data: ${error.message}</div>`;
        }
    }

    renderGamification(points, leaderboard, achievements) {
        return `
            <div class="gamification-container">
                <div class="points-section">
                    <div class="points-card">
                        <h3>Your Points</h3>
                        <div class="points-display">${points.total || 0}</div>
                        <p>Current Streak: ${points.streak || 0} days 🔥</p>
                        <button class="btn-primary" onclick="claimDailyReward()">Claim Daily Reward</button>
                    </div>
                </div>

                <div class="achievements-section">
                    <h3>Achievements</h3>
                    <div class="achievements-grid">
                        ${(achievements || []).map(achievement => `
                            <div class="achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}">
                                <div class="achievement-icon">${achievement.icon || '🏆'}</div>
                                <h4>${achievement.title}</h4>
                                <p>${achievement.description}</p>
                                ${achievement.unlocked ? `<span class="unlocked-date">Earned</span>` : `<span class="progress">${achievement.progress}%</span>`}
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="leaderboard-section">
                    <h3>Leaderboard 🏅</h3>
                    <table class="leaderboard-table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>User</th>
                                <th>Points</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${(leaderboard || []).map((user, index) => `
                                <tr ${user.id === this.currentUser.id ? 'class="current-user"' : ''}>
                                    <td>#${index + 1}</td>
                                    <td>${user.username}</td>
                                    <td>${user.points}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    async claimDailyReward() {
        try {
            const result = await pearl.claimDailyRewards();
            pearl.showSuccess(`Claimed ${result.points} points!`);
            this.loadGamification(); // Refresh
        } catch (error) {
            pearl.showError(error.message);
        }
    }

    // ============================================
    // CONTENT SECTION
    // ============================================

    async loadContent() {
        const container = document.querySelector('[data-tab-content="content"]');
        container.innerHTML = '<div class="loading">Loading content recommendations...</div>';

        try {
            const skills = await pearl.getUserSkills(this.currentUser.id);
            let contentHtml = '';

            for (const skill of skills) {
                const content = await pearl.getContentRecommendations(this.currentUser.id, skill.id);
                contentHtml += this.renderSkillContent(skill.name, content);
            }

            container.innerHTML = contentHtml || '<p>No content recommendations yet.</p>';
        } catch (error) {
            container.innerHTML = `<div class="error">Failed to load content: ${error.message}</div>`;
        }
    }

    renderSkillContent(skillName, content) {
        if (!content || content.length === 0) return '';

        return `
            <div class="skill-content-section">
                <h3>${skillName}</h3>
                <div class="content-grid">
                    ${content.map(item => `
                        <div class="content-card">
                            <h4>${item.title}</h4>
                            <p class="provider">${item.provider}</p>
                            <p class="duration">⏱️ ${item.duration}</p>
                            <p class="description">${(item.description || '').substring(0, 100)}...</p>
                            <button class="btn-secondary" onclick="window.open('${item.url}', '_blank')">
                                View Content
                            </button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // Initialize dashboard
    static initDashboard() {
        window.dashboard = new PEARLDashboard();
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    PEARLDashboard.initDashboard();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PEARLDashboard;
}
