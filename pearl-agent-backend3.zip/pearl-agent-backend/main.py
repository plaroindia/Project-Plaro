"""
Fixed Main Entry Point with Better Error Handling
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
import os
import sys
import traceback

# Create app
app = FastAPI(
    title="PEARL Agent API", 
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS - Allow all origins for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"]
)

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle all unhandled exceptions"""
    error_detail = {
        "error": str(exc),
        "type": type(exc).__name__,
        "path": str(request.url),
        "method": request.method
    }
    
    # Log the full traceback
    print(f"\n[ERROR] Unhandled exception at {request.url}")
    print(traceback.format_exc())
    
    return JSONResponse(
        status_code=500,
        content=error_detail
    )

# Import routes with error handling
routes_loaded = {
    'auth': False,
    'pearl': False,
    'api': False
}

try:
    from routes import auth_routes
    app.include_router(auth_routes.router, prefix="/auth", tags=["auth"])
    routes_loaded['auth'] = True
    print("[SUCCESS] Auth routes loaded")
except Exception as e:
    print(f"[ERROR] Failed to load auth routes: {e}")
    traceback.print_exc()

try:
    from routes import pearl_routes
    app.include_router(pearl_routes.router, prefix="/agent", tags=["pearl"])
    routes_loaded['pearl'] = True
    print("[SUCCESS] Pearl routes loaded")
except Exception as e:
    print(f"[ERROR] Failed to load pearl routes: {e}")
    traceback.print_exc()

try:
    from routes import new_routes
    app.include_router(new_routes.router, prefix="/api", tags=["api"])
    routes_loaded['api'] = True
    print("[SUCCESS] API routes loaded")
except Exception as e:
    print(f"[ERROR] Failed to load API routes: {e}")
    traceback.print_exc()

# Mount Pearl folder as static files
pearl_path = os.path.join(os.path.dirname(__file__), "Pearl")
if os.path.exists(pearl_path):
    app.mount("/", StaticFiles(directory=pearl_path, html=True), name="pearl")
    print(f"[SUCCESS] Pearl frontend mounted at http://localhost:8000/")
else:
    print(f"[WARNING] Pearl folder not found at {pearl_path}")

# Root endpoint
@app.get("/api-status")
async def root():
    return {
        "status": "online",
        "message": "PEARL Agent API",
        "version": "2.0.0",
        "routes_loaded": routes_loaded,
        "frontend": "http://localhost:8000/",
        "endpoints": {
            "auth": "/auth/signup, /auth/signin, /auth/signout" if routes_loaded['auth'] else "Not loaded",
            "agent": "/agent/start-journey" if routes_loaded['pearl'] else "Not loaded",
            "api": "/api/onboarding, /api/gamification, /api/resume, /api/analytics" if routes_loaded['api'] else "Not loaded",
            "docs": "/docs",
            "frontend": "http://localhost:8000/"
        }
    }

# Health check
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "service": "PEARL Agent",
        "frontend_url": "http://localhost:8000/",
        "routes_loaded": routes_loaded
    }

# Test endpoint
@app.get("/test")
async def test():
    return {
        "message": "API is working",
        "frontend": "http://localhost:8000/",
        "routes": routes_loaded
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app", 
        host="0.0.0.0", 
        port=8000, 
        reload=True,
        log_level="info"
    )