/**
 * Module Actions Handler - Core functionality for Taiken-as-Module
 * Handles: Learn, Practice, Checkpoint actions within modules
 */

const API_URL = window.location.hostname === 'localhost' ? 'http://localhost:8000' : window.location.origin;

// Get auth token and user
function getAuth() {
    const authToken = localStorage.getItem('auth_token');
    const currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
    return { authToken, currentUser };
}

// API call helper
async function apiCall(endpoint, options = {}) {
    const { authToken } = getAuth();
    const url = `${API_URL}${endpoint}`;
    
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (authToken && !options.skipAuth) {
        headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    const config = {
        method: options.method || 'GET',
        headers,
        ...options
    };
    
    if (options.body && typeof options.body === 'object') {
        config.body = JSON.stringify(options.body);
    }
    
    try {
        const response = await fetch(url, config);
        
        if (response.status === 401) {
            window.location.href = '/login.html';
            throw new Error('Session expired');
        }
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.detail || errorData.error || `HTTP ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error(`[API] Error on ${endpoint}:`, error);
        throw error;
    }
}

/**
 * Display module actions (Learn, Practice, Checkpoint) in a modal
 */
async function displayModuleActions(sessionId, skill, moduleId, moduleData) {
    const actions = moduleData.actions || [];
    const moduleName = moduleData.name || `Module ${moduleId}`;
    
    // Create modal HTML
    const modalHTML = `
        <div class="module-actions-modal" id="moduleActionsModal">
            <div class="modal-overlay"></div>
            <div class="modal-content module-actions-content">
                <button class="modal-close" onclick="closeModuleActionsModal()">
                    <i class="fas fa-times"></i>
                </button>
                
                <div class="module-actions-header">
                    <div class="module-icon-large">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div>
                        <h2>${moduleName}</h2>
                        <p class="module-skill">Skill: ${skill}</p>
                        <div class="module-progress-indicator">
                            <span>Progress: ${moduleData.actions_completed || 0}/${moduleData.total_actions || actions.length}</span>
                            <div class="progress-bar-small">
                                <div class="progress-fill" style="width: ${((moduleData.actions_completed || 0) / (moduleData.total_actions || actions.length)) * 100}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="module-actions-body">
                    <div class="actions-list" id="actionsList">
                        ${actions.map((action, index) => generateActionHTML(action, index, skill, moduleId, sessionId)).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    const existingModal = document.getElementById('moduleActionsModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    attachActionEventListeners(sessionId, skill, moduleId);
    
    // Show modal
    document.getElementById('moduleActionsModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

/**
 * Generate HTML for a single action
 */
function generateActionHTML(action, index, skill, moduleId, sessionId) {
    const isCompleted = action.completed || false;
    const actionType = action.type || 'learn';
    const actionIcon = getActionIcon(actionType);
    const actionLabel = getActionLabel(actionType);
    
    return `
        <div class="action-item ${isCompleted ? 'completed' : ''}" data-action-index="${index}" data-action-type="${actionType}">
            <div class="action-status">
                ${isCompleted ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-circle"></i>'}
            </div>
            <div class="action-content">
                <div class="action-header">
                    <div class="action-icon ${actionType}">
                        <i class="${actionIcon}"></i>
                    </div>
                    <div>
                        <h4>${action.title || actionLabel}</h4>
                        <p class="action-description">${action.description || getActionDescription(actionType)}</p>
                    </div>
                </div>
                
                ${!isCompleted ? `
                    <div class="action-body" id="actionBody-${index}">
                        ${renderActionBody(action, index, skill, moduleId, sessionId)}
                    </div>
                    
                    <div class="action-footer">
                        <button class="btn primary small" onclick="startAction(${index}, '${skill}', ${moduleId}, '${sessionId}')">
                            <i class="fas fa-play"></i>
                            ${actionType === 'checkpoint' ? 'Take Checkpoint' : actionType === 'practice' ? 'Start Practice' : 'Start Learning'}
                        </button>
                    </div>
                ` : `
                    <div class="action-completed-badge">
                        <i class="fas fa-check"></i>
                        <span>Completed</span>
                    </div>
                `}
            </div>
        </div>
    `;
}

/**
 * Render action body based on type
 */
function renderActionBody(action, index, skill, moduleId, sessionId) {
    const actionType = action.type || 'learn';
    
    switch(actionType) {
        case 'learn':
            return renderLearnAction(action, index);
        case 'practice':
            return renderPracticeAction(action, index);
        case 'checkpoint':
            return renderCheckpointAction(action, index);
        case 'byte':
        case 'course':
        case 'taiken':
            return renderContentAction(action, index);
        default:
            return '<p>Action content will be displayed here</p>';
    }
}

/**
 * Render Learn action (reading/video content)
 */
function renderLearnAction(action, index) {
    const resource = action.external_resource || {};
    return `
        <div class="learn-content">
            ${resource.title ? `<h5>${resource.title}</h5>` : ''}
            ${resource.description ? `<p>${resource.description}</p>` : ''}
            ${resource.url ? `
                <a href="${resource.url}" target="_blank" class="resource-link">
                    <i class="fas fa-external-link-alt"></i>
                    Open Resource
                </a>
            ` : ''}
            ${resource.platform ? `<p class="resource-platform"><i class="fas fa-tag"></i> ${resource.platform}</p>` : ''}
        </div>
    `;
}

/**
 * Render Practice action
 */
function renderPracticeAction(action, index) {
    const task = action.task || action.description || 'Practice exercise';
    return `
        <div class="practice-content">
            <p><strong>Practice Task:</strong></p>
            <p>${task}</p>
            ${action.expected_output ? `
                <div class="practice-hint">
                    <i class="fas fa-lightbulb"></i>
                    <strong>Expected Output:</strong> ${action.expected_output}
                </div>
            ` : ''}
        </div>
    `;
}

/**
 * Render Checkpoint action
 */
function renderCheckpointAction(action, index) {
    const questions = action.questions || [];
    return `
        <div class="checkpoint-content">
            <p><strong>Checkpoint Assessment</strong></p>
            <p>Answer ${questions.length} questions to validate your understanding.</p>
            <div class="checkpoint-preview">
                <i class="fas fa-clipboard-check"></i>
                <span>${questions.length} Questions</span>
            </div>
        </div>
    `;
}

/**
 * Render Content action (byte/course/taiken)
 */
function renderContentAction(action, index) {
    const resource = action.external_resource || {};
    return `
        <div class="content-action">
            ${resource.title ? `<h5>${resource.title}</h5>` : ''}
            ${resource.description ? `<p>${resource.description}</p>` : ''}
            ${resource.url ? `
                <a href="${resource.url}" target="_blank" class="btn outline">
                    <i class="fas fa-external-link-alt"></i>
                    Open ${action.type === 'taiken' ? 'Taiken Story' : action.type === 'course' ? 'Course' : 'Content'}
                </a>
            ` : ''}
        </div>
    `;
}

/**
 * Start an action
 */
async function startAction(actionIndex, skill, moduleId, sessionId) {
    try {
        const { currentUser } = getAuth();
        
        // Get current action data
        const actionItem = document.querySelector(`[data-action-index="${actionIndex}"]`);
        const actionType = actionItem?.getAttribute('data-action-type') || 'learn';
        
        if (actionType === 'checkpoint') {
            // Open checkpoint modal
            await openCheckpointModal(sessionId, skill, moduleId, actionIndex);
        } else if (actionType === 'practice') {
            // Open practice interface
            await openPracticeInterface(sessionId, skill, moduleId, actionIndex);
        } else {
            // Mark as in progress and show content
            actionItem?.classList.add('in-progress');
            showNotification('Action started! Complete it to mark as done.', 'info');
        }
        
    } catch (error) {
        console.error('[ACTION] Start error:', error);
        showNotification('Failed to start action', 'error');
    }
}

/**
 * Complete an action
 */
async function completeAction(sessionId, skill, moduleId, actionIndex, completionData = {}) {
    try {
        const { currentUser } = getAuth();
        
        const response = await apiCall('/agent/complete-action', {
            method: 'POST',
            body: {
                session_id: sessionId,
                skill: skill,
                module_id: moduleId,
                action_index: actionIndex,
                completion_data: {
                    action_type: completionData.action_type || 'learn',
                    ...completionData
                },
                user_id: currentUser.id
            }
        });
        
        if (response.success) {
            // Update UI
            const actionItem = document.querySelector(`[data-action-index="${actionIndex}"]`);
            if (actionItem) {
                actionItem.classList.remove('in-progress');
                actionItem.classList.add('completed');
                actionItem.querySelector('.action-status i').className = 'fas fa-check-circle';
                
                // Replace action body with completed badge
                const actionBody = actionItem.querySelector('.action-body');
                const actionFooter = actionItem.querySelector('.action-footer');
                if (actionBody) actionBody.remove();
                if (actionFooter) {
                    actionFooter.innerHTML = `
                        <div class="action-completed-badge">
                            <i class="fas fa-check"></i>
                            <span>Completed</span>
                        </div>
                    `;
                }
            }
            
            // Update progress
            updateModuleProgress(sessionId, skill, moduleId);
            
            // Show next action if available
            if (response.next_action) {
                showNotification('Action completed! Next action available.', 'success');
            } else {
                showNotification('Action completed!', 'success');
            }
            
            return response;
        }
        
    } catch (error) {
        console.error('[ACTION] Complete error:', error);
        showNotification('Failed to complete action', 'error');
        throw error;
    }
}

/**
 * Open checkpoint modal
 */
async function openCheckpointModal(sessionId, skill, moduleId, actionIndex) {
    try {
        // Get checkpoint data from session
        const sessionData = await apiCall(`/api/learning/session/${sessionId}`);
        const learning_paths = sessionData.session?.jd_parsed?.learning_paths || {};
        const learning_path = learning_paths[skill];
        
        if (!learning_path) {
            throw new Error('Learning path not found');
        }
        
        const module = learning_path.modules.find(m => m.module_id === moduleId);
        if (!module) {
            throw new Error('Module not found');
        }
        
        const checkpointAction = module.actions[actionIndex];
        if (!checkpointAction || checkpointAction.type !== 'checkpoint') {
            throw new Error('Checkpoint action not found');
        }
        
        const questions = checkpointAction.questions || [];
        
        // Create checkpoint modal
        const checkpointHTML = `
            <div class="checkpoint-modal" id="checkpointModal">
                <div class="modal-overlay"></div>
                <div class="modal-content checkpoint-content">
                    <button class="modal-close" onclick="closeCheckpointModal()">
                        <i class="fas fa-times"></i>
                    </button>
                    
                    <div class="checkpoint-header">
                        <h2><i class="fas fa-clipboard-check"></i> Checkpoint Assessment</h2>
                        <p>Answer all questions to validate your understanding</p>
                    </div>
                    
                    <div class="checkpoint-body">
                        <form id="checkpointForm">
                            ${questions.map((q, qIndex) => `
                                <div class="checkpoint-question">
                                    <div class="question-header">
                                        <span class="question-number">${qIndex + 1}</span>
                                        <h4>${q.question || q.question_text}</h4>
                                    </div>
                                    <div class="question-options">
                                        ${(q.options || []).map((option, oIndex) => `
                                            <label class="option-label">
                                                <input type="radio" name="question-${qIndex}" value="${oIndex}" required>
                                                <span class="option-text">${option}</span>
                                            </label>
                                        `).join('')}
                                    </div>
                                </div>
                            `).join('')}
                        </form>
                    </div>
                    
                    <div class="checkpoint-footer">
                        <button class="btn outline" onclick="closeCheckpointModal()">Cancel</button>
                        <button class="btn primary" onclick="submitCheckpoint('${sessionId}', '${skill}', ${moduleId})">
                            <i class="fas fa-paper-plane"></i>
                            Submit Answers
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing checkpoint modal
        const existing = document.getElementById('checkpointModal');
        if (existing) existing.remove();
        
        document.body.insertAdjacentHTML('beforeend', checkpointHTML);
        document.getElementById('checkpointModal').classList.add('active');
        document.body.style.overflow = 'hidden';
        
    } catch (error) {
        console.error('[CHECKPOINT] Open error:', error);
        showNotification('Failed to load checkpoint', 'error');
    }
}

/**
 * Submit checkpoint
 */
async function submitCheckpoint(sessionId, skill, moduleId) {
    try {
        const form = document.getElementById('checkpointForm');
        if (!form) return;
        
        const questions = form.querySelectorAll('.checkpoint-question');
        const answers = [];
        
        questions.forEach((question, index) => {
            const selected = question.querySelector('input[type="radio"]:checked');
            if (!selected) {
                throw new Error(`Please answer question ${index + 1}`);
            }
            answers.push(parseInt(selected.value));
        });
        
        const { currentUser } = getAuth();
        
        const response = await apiCall('/agent/submit-checkpoint', {
            method: 'POST',
            body: {
                session_id: sessionId,
                skill: skill,
                module_id: moduleId,
                answers: answers,
                user_id: currentUser.id
            }
        });
        
        if (response.checkpoint_result) {
            const result = response.checkpoint_result;
            const passed = result.passed;
            const score = result.score;
            
            // Close modal
            closeCheckpointModal();
            
            // Show result
            showCheckpointResult(passed, score, result.feedback);
            
            // If passed, mark action as complete
            if (passed) {
                // Find and mark checkpoint action as complete
                const actionItems = document.querySelectorAll('.action-item');
                actionItems.forEach(item => {
                    if (item.getAttribute('data-action-type') === 'checkpoint') {
                        item.classList.add('completed');
                        item.querySelector('.action-status i').className = 'fas fa-check-circle';
                    }
                });
                
                // Update module progress
                updateModuleProgress(sessionId, skill, moduleId);
            }
        }
        
    } catch (error) {
        console.error('[CHECKPOINT] Submit error:', error);
        showNotification(error.message || 'Failed to submit checkpoint', 'error');
    }
}

/**
 * Show checkpoint result
 */
function showCheckpointResult(passed, score, feedback) {
    const resultHTML = `
        <div class="checkpoint-result-modal" id="checkpointResultModal">
            <div class="modal-overlay"></div>
            <div class="modal-content result-content">
                <div class="result-icon ${passed ? 'success' : 'failed'}">
                    <i class="fas ${passed ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                </div>
                <h2>${passed ? 'Checkpoint Passed!' : 'Checkpoint Failed'}</h2>
                <p class="result-score">Score: ${score}%</p>
                ${feedback ? `<p class="result-feedback">${feedback}</p>` : ''}
                <button class="btn primary" onclick="closeCheckpointResult()">Continue</button>
            </div>
        </div>
    `;
    
    const existing = document.getElementById('checkpointResultModal');
    if (existing) existing.remove();
    
    document.body.insertAdjacentHTML('beforeend', resultHTML);
    document.getElementById('checkpointResultModal').classList.add('active');
}

/**
 * Open practice interface
 */
async function openPracticeInterface(sessionId, skill, moduleId, actionIndex) {
    // Redirect to practice page or open practice modal
    showNotification('Practice interface coming soon!', 'info');
    // For now, mark as in progress
    const actionItem = document.querySelector(`[data-action-index="${actionIndex}"]`);
    if (actionItem) {
        actionItem.classList.add('in-progress');
    }
}

/**
 * Update module progress
 */
async function updateModuleProgress(sessionId, skill, moduleId) {
    try {
        const progress = await apiCall(`/agent/progress/${sessionId}/${skill}`);
        
        // Update progress indicators in UI
        const progressIndicators = document.querySelectorAll('.module-progress-indicator');
        progressIndicators.forEach(indicator => {
            const progressBar = indicator.querySelector('.progress-fill');
            if (progressBar) {
                progressBar.style.width = `${progress.progress_percentage || 0}%`;
            }
        });
        
    } catch (error) {
        console.error('[PROGRESS] Update error:', error);
    }
}

/**
 * Close modals
 */
function closeModuleActionsModal() {
    const modal = document.getElementById('moduleActionsModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
        setTimeout(() => modal.remove(), 300);
    }
}

function closeCheckpointModal() {
    const modal = document.getElementById('checkpointModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
        setTimeout(() => modal.remove(), 300);
    }
}

function closeCheckpointResult() {
    const modal = document.getElementById('checkpointResultModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
        setTimeout(() => modal.remove(), 300);
    }
}

/**
 * Attach event listeners
 */
function attachActionEventListeners(sessionId, skill, moduleId) {
    // Add listeners for action completion buttons, etc.
}

/**
 * Helper functions
 */
function getActionIcon(type) {
    const icons = {
        'learn': 'fas fa-book',
        'practice': 'fas fa-code',
        'checkpoint': 'fas fa-clipboard-check',
        'byte': 'fas fa-video',
        'course': 'fas fa-graduation-cap',
        'taiken': 'fas fa-book-open'
    };
    return icons[type] || 'fas fa-circle';
}

function getActionLabel(type) {
    const labels = {
        'learn': 'Learn',
        'practice': 'Practice',
        'checkpoint': 'Checkpoint',
        'byte': 'Video Content',
        'course': 'Course',
        'taiken': 'Taiken Story'
    };
    return labels[type] || 'Action';
}

function getActionDescription(type) {
    const descriptions = {
        'learn': 'Study the learning materials',
        'practice': 'Complete practice exercises',
        'checkpoint': 'Take assessment to validate understanding',
        'byte': 'Watch video content',
        'course': 'Complete course module',
        'taiken': 'Experience interactive story'
    };
    return descriptions[type] || 'Complete this action';
}

function showNotification(message, type = 'info') {
    // Use existing notification system or create simple alert
    if (typeof window.showNotification === 'function') {
        window.showNotification(message, type);
    } else {
        alert(message);
    }
}

// Make functions globally available
window.displayModuleActions = displayModuleActions;
window.startAction = startAction;
window.completeAction = completeAction;
window.submitCheckpoint = submitCheckpoint;
window.closeModuleActionsModal = closeModuleActionsModal;
window.closeCheckpointModal = closeCheckpointModal;
window.closeCheckpointResult = closeCheckpointResult;
