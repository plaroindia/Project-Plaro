// Enhanced Onboarding with Professional UX
const onboardingData = {
  step1: {
    currentRole: '',
    dreamJob: '',
    shortTermGoals: '',
    longTermGoals: '',
    timeline: null
  },
  step2: {
    interests: [],
    hobbies: '',
    learningTopics: '',
    intensity: 5
  },
  step3: {
    skills: [],
    skillGaps: '',
    certifications: '',
    experience: '',
    confidence: null
  },
  step4: {
    formats: [],
    learningStyle: '',
    times: [],
    weeklyHours: '',
    challenges: '',
    motivations: []
  }
};

// UI State
let currentStep = 1;
const totalSteps = 4;
let isAnimating = false;

// Initialize
function initOnboarding() {
  console.log('Initializing enhanced onboarding...');
  
  // Load saved data
  loadSavedData();
  
  // Setup event listeners
  setupEventListeners();
  
  // Initialize interactive elements
  initInteractiveElements();
  
  // Show initial step
  showStep(1);
  
  // Update progress
  updateProgress();
  
  console.log('Onboarding initialized successfully');
}

// Load saved data
function loadSavedData() {
  try {
    const savedData = localStorage.getItem('onboardingData');
    if (savedData) {
      const parsedData = JSON.parse(savedData);
      Object.assign(onboardingData, parsedData);
      console.log('Loaded saved data:', onboardingData);
      
      // Apply to UI
      applySavedData();
    }
  } catch (error) {
    console.error('Error loading saved data:', error);
  }
}

// Apply saved data to UI
function applySavedData() {
  // Step 1
  setValue('currentRole', onboardingData.step1.currentRole);
  setValue('dreamJob', onboardingData.step1.dreamJob);
  setValue('shortTermGoals', onboardingData.step1.shortTermGoals);
  setValue('longTermGoals', onboardingData.step1.longTermGoals);
  
  if (onboardingData.step1.timeline) {
    const radio = document.querySelector(`input[name="timeline"][value="${onboardingData.step1.timeline}"]`);
    if (radio) {
      radio.checked = true;
      radio.parentElement.classList.add('selected');
    }
  }
  
  // Step 2
  renderInterests();
  setValue('hobbies', onboardingData.step2.hobbies);
  setValue('learningTopics', onboardingData.step2.learningTopics);
  
  const intensitySlider = document.getElementById('interestIntensity');
  if (intensitySlider && onboardingData.step2.intensity) {
    intensitySlider.value = onboardingData.step2.intensity;
    document.getElementById('intensityValue').textContent = onboardingData.step2.intensity;
  }
  
  // Step 3
  renderSkills();
  setValue('skillGaps', onboardingData.step3.skillGaps);
  setValue('certifications', onboardingData.step3.certifications);
  setValue('experience', onboardingData.step3.experience);
  
  if (onboardingData.step3.confidence) {
    const radio = document.querySelector(`input[name="confidence"][value="${onboardingData.step3.confidence}"]`);
    if (radio) {
      radio.checked = true;
      radio.parentElement.classList.add('selected');
    }
  }
  
  // Step 4
  if (onboardingData.step4.formats) {
    onboardingData.step4.formats.forEach(format => {
      const checkbox = document.querySelector(`input[name="format"][value="${format}"]`);
      if (checkbox) {
        checkbox.checked = true;
        checkbox.parentElement.classList.add('selected');
      }
    });
  }
  
  setValue('learningStyle', onboardingData.step4.learningStyle);
  
  if (onboardingData.step4.times) {
    onboardingData.step4.times.forEach(time => {
      const checkbox = document.querySelector(`input[name="time"][value="${time}"]`);
      if (checkbox) {
        checkbox.checked = true;
        checkbox.parentElement.classList.add('selected');
      }
    });
  }
  
  setValue('weeklyHours', onboardingData.step4.weeklyHours);
  setValue('challenges', onboardingData.step4.challenges);
  
  if (onboardingData.step4.motivations) {
    onboardingData.step4.motivations.forEach(motivation => {
      const checkbox = document.querySelector(`input[name="motivation"][value="${motivation}"]`);
      if (checkbox) {
        checkbox.checked = true;
        checkbox.parentElement.classList.add('selected');
      }
    });
  }
}

// Helper to set value with animation
function setValue(id, value) {
  const element = document.getElementById(id);
  if (element && value) {
    element.value = value;
    
    // Trigger floating label animation
    if (value.trim() !== '') {
      element.classList.add('has-value');
    }
  }
}

// Setup event listeners
function setupEventListeners() {
  console.log('Setting up event listeners...');
  
  // Navigation buttons
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  
  if (prevBtn) {
    prevBtn.addEventListener('click', goToPreviousStep);
  }
  
  if (nextBtn) {
    nextBtn.addEventListener('click', goToNextStep);
  }
  
  // Step items in sidebar
  document.querySelectorAll('.step-item').forEach(item => {
    item.addEventListener('click', function() {
      const stepNumber = parseInt(this.dataset.step);
      if (stepNumber <= currentStep) {
        showStep(stepNumber);
      }
    });
  });
  
  // Back button
  const backBtn = document.querySelector('.back-btn');
  if (backBtn) {
    backBtn.addEventListener('click', goBack);
  }
  
  // Theme toggle
  const themeToggle = document.querySelector('.theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
  
  // Skip button
  const skipBtn = document.querySelector('.btn-skip');
  if (skipBtn) {
    skipBtn.addEventListener('click', skipOnboarding);
  }
  
  // Auto-save on input
  document.addEventListener('input', function(e) {
    if (e.target.matches('input, textarea, select')) {
      saveCurrentStepData();
    }
  });
  
  // Auto-save on change
  document.addEventListener('change', function(e) {
    if (e.target.matches('input, select')) {
      saveCurrentStepData();
      
      // Add visual feedback for selection
      if (e.target.type === 'radio' || e.target.type === 'checkbox') {
        const card = e.target.closest('.timeline-card, .confidence-card, .preference-card, .motivation-card');
        if (card) {
          card.classList.add('selected');
        }
      }
    }
  });
  
  // Enter key for interest/skill input
  const interestInput = document.getElementById('interestInput');
  const skillInput = document.getElementById('skillInput');
  
  if (interestInput) {
    interestInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        addInterest();
      }
    });
  }
  
  if (skillInput) {
    skillInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        addSkill();
      }
    });
  }
  
  // Intensity slider
  const intensitySlider = document.getElementById('interestIntensity');
  if (intensitySlider) {
    intensitySlider.addEventListener('input', function() {
      document.getElementById('intensityValue').textContent = this.value;
      saveCurrentStepData();
    });
  }
  
  console.log('Event listeners setup complete');
}

// Initialize interactive elements
function initInteractiveElements() {
  // Initialize floating labels
  document.querySelectorAll('.form-group.floating input, .form-group.floating textarea, .form-group.floating select').forEach(element => {
    if (element.value.trim() !== '') {
      element.classList.add('has-value');
    }
    
    element.addEventListener('focus', function() {
      this.parentElement.classList.add('focused');
    });
    
    element.addEventListener('blur', function() {
      this.parentElement.classList.remove('focused');
    });
  });
  
  // Initialize card interactions
  document.querySelectorAll('.timeline-card, .confidence-card, .preference-card, .motivation-card').forEach(card => {
    card.addEventListener('click', function() {
      const input = this.querySelector('input');
      if (input) {
        // For checkboxes, toggle
        if (input.type === 'checkbox') {
          input.checked = !input.checked;
        }
        // For radio buttons, just check
        else if (input.type === 'radio') {
          input.checked = true;
        }
        
        // Trigger change event
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  });
  
  // Initialize counters
  updateInterestCounter();
  updateSkillCounter();
}

// Show step with animation
function showStep(stepNumber) {
  if (isAnimating || stepNumber < 1 || stepNumber > totalSteps) return;
  
  isAnimating = true;
  console.log(`Showing step ${stepNumber}`);
  
  // Save current step data before leaving
  saveCurrentStepData();
  
  // Update current step
  currentStep = stepNumber;
  
  // Hide all step contents
  document.querySelectorAll('.step-content').forEach(content => {
    content.classList.remove('active');
    content.classList.add('hidden');
  });
  
  // Show current step content with animation
  const currentContent = document.getElementById(`step${stepNumber}`);
  if (currentContent) {
    setTimeout(() => {
      currentContent.classList.remove('hidden');
      currentContent.classList.add('active');
      
      // Trigger animation
      currentContent.style.animation = 'fadeInUp 0.5s ease forwards';
      
      // Update progress indicators
      updateProgress();
      updateStepIndicators();
      updateNavigationButtons();
      
      // Scroll to top
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        isAnimating = false;
      }, 300);
    }, 100);
  }
}

// Update progress circle and indicators
function updateProgress() {
  const progress = (currentStep / totalSteps) * 100;
  
  // Update progress circle
  const progressFg = document.querySelector('.progress-fg');
  if (progressFg) {
    const circumference = 2 * Math.PI * 54;
    const offset = circumference - (progress / 100) * circumference;
    progressFg.style.strokeDashoffset = offset;
  }
  
  // Update progress text
  const progressPercent = document.querySelector('.progress-percent');
  if (progressPercent) {
    progressPercent.textContent = `${Math.round(progress)}%`;
  }
  
  // Update step number in sidebar
  const stepNumberLarge = document.querySelector('.step-number-large');
  if (stepNumberLarge) {
    stepNumberLarge.innerHTML = `${currentStep}<span class="step-total">/${totalSteps}</span>`;
  }
  
  // Update step title in sidebar
  const stepTitleLarge = document.querySelector('.step-title-large');
  if (stepTitleLarge) {
    const stepTitles = ['Getting Started', 'Career Goals', 'Interests', 'Skills', 'Preferences'];
    stepTitleLarge.textContent = stepTitles[currentStep];
  }
  
  // Update step items
  document.querySelectorAll('.step-item').forEach((item, index) => {
    const itemStep = index + 1;
    
    if (itemStep === currentStep) {
      item.classList.add('active');
      item.classList.remove('completed');
    } else if (itemStep < currentStep) {
      item.classList.remove('active');
      item.classList.add('completed');
    } else {
      item.classList.remove('active', 'completed');
    }
  });
}

// Update step indicators
function updateStepIndicators() {
  // Update content step counter
  const currentStepLarge = document.querySelector('.current-step-large');
  const totalStepsLarge = document.querySelector('.total-steps-large');
  
  if (currentStepLarge) {
    currentStepLarge.textContent = currentStep.toString().padStart(2, '0');
  }
  
  if (totalStepsLarge) {
    totalStepsLarge.textContent = totalSteps.toString().padStart(2, '0');
  }
}

// Update navigation buttons
function updateNavigationButtons() {
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  
  if (!prevBtn || !nextBtn) return;
  
  // Previous button
  if (currentStep === 1) {
    prevBtn.style.display = 'none';
  } else {
    prevBtn.style.display = 'flex';
  }
  
  // Next button
  if (currentStep === totalSteps) {
    nextBtn.innerHTML = 'Complete <span class="material-icons">check</span>';
  } else {
    nextBtn.innerHTML = 'Continue <span class="material-icons">arrow_forward</span>';
  }
}

// Save current step data
function saveCurrentStepData() {
  console.log(`Saving step ${currentStep} data`);
  
  try {
    switch(currentStep) {
      case 1:
        saveStep1Data();
        break;
      case 2:
        saveStep2Data();
        break;
      case 3:
        saveStep3Data();
        break;
      case 4:
        saveStep4Data();
        break;
    }
    
    // Save to localStorage
    localStorage.setItem('onboardingData', JSON.stringify(onboardingData));
    
    // Show saved indicator
    showSavedIndicator();
    
    console.log('Data saved successfully');
  } catch (error) {
    console.error('Error saving data:', error);
  }
}

// Step 1 data collection
function saveStep1Data() {
  onboardingData.step1.currentRole = getValue('currentRole');
  onboardingData.step1.dreamJob = getValue('dreamJob');
  onboardingData.step1.shortTermGoals = getValue('shortTermGoals');
  onboardingData.step1.longTermGoals = getValue('longTermGoals');
  
  const selectedTimeline = document.querySelector('input[name="timeline"]:checked');
  onboardingData.step1.timeline = selectedTimeline ? selectedTimeline.value : null;
}

// Step 2 data collection
function saveStep2Data() {
  onboardingData.step2.hobbies = getValue('hobbies');
  onboardingData.step2.learningTopics = getValue('learningTopics');
  
  const intensitySlider = document.getElementById('interestIntensity');
  onboardingData.step2.intensity = intensitySlider ? parseInt(intensitySlider.value) : 5;
}

// Step 3 data collection
function saveStep3Data() {
  onboardingData.step3.skillGaps = getValue('skillGaps');
  onboardingData.step3.certifications = getValue('certifications');
  onboardingData.step3.experience = getValue('experience');
  
  const selectedConfidence = document.querySelector('input[name="confidence"]:checked');
  onboardingData.step3.confidence = selectedConfidence ? selectedConfidence.value : null;
}

// Step 4 data collection
function saveStep4Data() {
  // Formats
  const selectedFormats = [];
  document.querySelectorAll('input[name="format"]:checked').forEach(checkbox => {
    selectedFormats.push(checkbox.value);
  });
  onboardingData.step4.formats = selectedFormats;
  
  // Learning style
  onboardingData.step4.learningStyle = getValue('learningStyle');
  
  // Times
  const selectedTimes = [];
  document.querySelectorAll('input[name="time"]:checked').forEach(checkbox => {
    selectedTimes.push(checkbox.value);
  });
  onboardingData.step4.times = selectedTimes;
  
  // Weekly hours
  onboardingData.step4.weeklyHours = getValue('weeklyHours');
  
  // Challenges
  onboardingData.step4.challenges = getValue('challenges');
  
  // Motivations
  const selectedMotivations = [];
  document.querySelectorAll('input[name="motivation"]:checked').forEach(checkbox => {
    selectedMotivations.push(checkbox.value);
  });
  onboardingData.step4.motivations = selectedMotivations;
}

// Helper to get value
function getValue(id) {
  const element = document.getElementById(id);
  return element ? element.value.trim() : '';
}

// Show saved indicator
function showSavedIndicator() {
  const savedStatus = document.querySelector('.saved-status');
  if (savedStatus) {
    savedStatus.classList.add('saved');
    savedStatus.innerHTML = '<span class="material-icons">cloud_done</span><span>Just saved</span>';
    
    setTimeout(() => {
      savedStatus.classList.remove('saved');
      savedStatus.innerHTML = '<span class="material-icons">cloud_done</span><span>Auto-saved</span>';
    }, 2000);
  }
}

// Interest management
function addInterest() {
  const input = document.getElementById('interestInput');
  const container = document.getElementById('selectedInterests');
  
  if (!input || !container) return;
  
  const interest = input.value.trim();
  if (interest && onboardingData.step2.interests.length < 5) {
    // Add to data
    onboardingData.step2.interests.push(interest);
    
    // Create tag
    const tag = document.createElement('div');
    tag.className = 'interest-tag';
    tag.innerHTML = `
      ${interest}
      <button type="button" class="remove-tag" onclick="removeInterest('${interest}')">
        <span class="material-icons">close</span>
      </button>
    `;
    
    container.appendChild(tag);
    input.value = '';
    
    // Save and update
    saveCurrentStepData();
    updateInterestCounter();
    
    // Focus input
    input.focus();
  }
}

function removeInterest(interest) {
  const index = onboardingData.step2.interests.indexOf(interest);
  if (index > -1) {
    onboardingData.step2.interests.splice(index, 1);
    saveCurrentStepData();
    renderInterests();
  }
}

function renderInterests() {
  const container = document.getElementById('selectedInterests');
  if (!container) return;
  
  container.innerHTML = '';
  onboardingData.step2.interests.forEach(interest => {
    const tag = document.createElement('div');
    tag.className = 'interest-tag';
    tag.innerHTML = `
      ${interest}
      <button type="button" class="remove-tag" onclick="removeInterest('${interest}')">
        <span class="material-icons">close</span>
      </button>
    `;
    container.appendChild(tag);
  });
  
  updateInterestCounter();
}

function updateInterestCounter() {
  const counter = document.getElementById('interestsCount');
  if (counter) {
    counter.textContent = onboardingData.step2.interests.length;
  }
}

// Skill management
function addSkill() {
  const input = document.getElementById('skillInput');
  const levelSelect = document.getElementById('skillLevelSelect');
  const container = document.getElementById('selectedSkills');
  
  if (!input || !levelSelect || !container) return;
  
  const skill = input.value.trim();
  const level = levelSelect.value;
  
  if (skill) {
    // Add to data
    onboardingData.step3.skills.push({ skill, level });
    
    // Create tag
    const tag = document.createElement('div');
    tag.className = 'skill-tag';
    tag.innerHTML = `
      ${skill}
      <span class="skill-level-badge">${level}</span>
      <button type="button" class="remove-tag" onclick="removeSkill('${skill}')">
        <span class="material-icons">close</span>
      </button>
    `;
    
    container.appendChild(tag);
    input.value = '';
    
    // Save and update
    saveCurrentStepData();
    updateSkillCounter();
    
    // Focus input
    input.focus();
  }
}

function removeSkill(skill) {
  const index = onboardingData.step3.skills.findIndex(s => s.skill === skill);
  if (index > -1) {
    onboardingData.step3.skills.splice(index, 1);
    saveCurrentStepData();
    renderSkills();
  }
}

function renderSkills() {
  const container = document.getElementById('selectedSkills');
  if (!container) return;
  
  container.innerHTML = '';
  onboardingData.step3.skills.forEach(({ skill, level }) => {
    const tag = document.createElement('div');
    tag.className = 'skill-tag';
    tag.innerHTML = `
      ${skill}
      <span class="skill-level-badge">${level}</span>
      <button type="button" class="remove-tag" onclick="removeSkill('${skill}')">
        <span class="material-icons">close</span>
      </button>
    `;
    container.appendChild(tag);
  });
  
  updateSkillCounter();
}

function updateSkillCounter() {
  const counter = document.getElementById('skillsCount');
  if (counter) {
    counter.textContent = onboardingData.step3.skills.length;
  }
}

// Navigation functions
function goToPreviousStep() {
  if (currentStep > 1 && !isAnimating) {
    showStep(currentStep - 1);
  }
}

function goToNextStep() {
  if (!validateCurrentStep()) {
    showValidationError();
    return;
  }
  
  if (currentStep < totalSteps && !isAnimating) {
    showStep(currentStep + 1);
  } else if (currentStep === totalSteps) {
    completeOnboarding();
  }
}

// Validate current step
function validateCurrentStep() {
  console.log(`Validating step ${currentStep}`);
  
  let isValid = true;
  let errorMessage = '';
  
  switch(currentStep) {
    case 1:
      const currentRole = getValue('currentRole');
      const dreamJob = getValue('dreamJob');
      const timeline = document.querySelector('input[name="timeline"]:checked');
      
      if (!currentRole || !dreamJob || !timeline) {
        isValid = false;
        errorMessage = 'Please fill in all required fields and select a timeline';
      }
      break;
      
    case 2:
      const hasInterests = onboardingData.step2.interests.length > 0;
      const learningTopics = getValue('learningTopics');
      
      if (!hasInterests || !learningTopics) {
        isValid = false;
        errorMessage = 'Please add at least one interest and specify learning topics';
      }
      break;
      
    case 3:
      const hasSkills = onboardingData.step3.skills.length > 0;
      const experience = getValue('experience');
      const confidence = document.querySelector('input[name="confidence"]:checked');
      
      if (!hasSkills || !experience || !confidence) {
        isValid = false;
        errorMessage = 'Please add skills, select experience level, and choose confidence level';
      }
      break;
      
    case 4:
      const hasFormats = document.querySelectorAll('input[name="format"]:checked').length > 0;
      const learningStyle = getValue('learningStyle');
      const hasTimes = document.querySelectorAll('input[name="time"]:checked').length > 0;
      const weeklyHours = getValue('weeklyHours');
      const hasMotivations = document.querySelectorAll('input[name="motivation"]:checked').length > 0;
      
      if (!hasFormats || !learningStyle || !hasTimes || !weeklyHours || !hasMotivations) {
        isValid = false;
        errorMessage = 'Please complete all learning preference sections';
      }
      break;
  }
  
  if (!isValid) {
    console.log('Validation failed:', errorMessage);
  }
  
  return isValid;
}

// Show validation error
function showValidationError() {
  // Remove existing errors
  document.querySelectorAll('.error-message').forEach(el => el.remove());
  
  // Create error message
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.innerHTML = `
    <span class="material-icons">error_outline</span>
    <span>Please complete all required fields</span>
  `;
  
  errorDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--error);
    color: white;
    padding: 16px 24px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 1000;
    animation: slideInRight 0.3s ease;
    box-shadow: 0 4px 12px rgba(255, 82, 82, 0.2);
    font-size: 14px;
  `;
  
  document.body.appendChild(errorDiv);
  
  // Add shake animation to current step
  const currentStepContent = document.getElementById(`step${currentStep}`);
  if (currentStepContent) {
    currentStepContent.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
      currentStepContent.style.animation = '';
    }, 500);
  }
  
  // Highlight required fields
  highlightRequiredFields();
  
  // Remove error after 3 seconds
  setTimeout(() => {
    errorDiv.style.animation = 'slideOutRight 0.3s ease';
    setTimeout(() => errorDiv.remove(), 300);
  }, 3000);
}

// Highlight required fields
function highlightRequiredFields() {
  const currentStepContent = document.getElementById(`step${currentStep}`);
  if (!currentStepContent) return;
  
  const requiredFields = currentStepContent.querySelectorAll('input[required], textarea[required], select[required]');
  
  requiredFields.forEach(field => {
    if (!field.value.trim()) {
      field.style.borderColor = 'var(--error)';
      field.style.boxShadow = '0 0 0 2px rgba(255, 82, 82, 0.2)';
      
      setTimeout(() => {
        field.style.borderColor = '';
        field.style.boxShadow = '';
      }, 2000);
    }
  });
}

// Complete onboarding
async function completeOnboarding() {
  console.log('Completing onboarding...');
  
  // Save final data
  saveCurrentStepData();
  
  // Prepare summary
  prepareSummary();
  
  // Get auth token
  const authToken = localStorage.getItem('auth_token');
  const currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
  const API_URL = window.location.hostname === 'localhost' ? 'http://localhost:8000' : window.location.origin;
  
  if (!authToken || !currentUser.id) {
    console.error('No auth token or user ID found');
    showNotification('Please sign in first', 'error');
    setTimeout(() => {
      window.location.href = '/login.html';
    }, 2000);
    return;
  }
  
  try {
    // Prepare onboarding data for backend
    const onboardingPayload = {
      primary_career_goal: onboardingData.step1.dreamJob || onboardingData.step1.currentRole,
      target_role: onboardingData.step1.dreamJob || onboardingData.step1.currentRole,
      current_status: onboardingData.step1.currentRole || 'student',
      skills: onboardingData.step3.skills.map(s => s.skill || s),
      time_availability: onboardingData.step1.timeline || '5-10 hours/week',
      learning_preference: onboardingData.step4.learningStyle || 'mixed',
      short_term_goal: onboardingData.step1.shortTermGoals,
      constraint_free_only: false,
      constraint_heavy_workload: false,
      confidence_baseline: onboardingData.step3.confidence ? parseInt(onboardingData.step3.confidence) : 3
    };
    
    // Submit to backend
    const response = await fetch(`${API_URL}/api/onboarding/start`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(onboardingPayload)
    });
    
    const data = await response.json();
    
    if (data.success) {
      // Mark as complete
      localStorage.setItem('onboardingComplete', 'true');
      localStorage.setItem('userOnboardingData', JSON.stringify(onboardingData));
      
      // Update user profile
      if (data.user_id) {
        currentUser.id = data.user_id;
        localStorage.setItem('user_data', JSON.stringify(currentUser));
      }
      
      // Store session ID if provided
      if (data.session_id) {
        localStorage.setItem('current_session_id', data.session_id);
      }
      
      // Show success modal
      showSuccessModal();
      
      // Auto-start journey after 2 seconds (if not already started)
      if (!data.session_id) {
        setTimeout(async () => {
          await startCareerJourney();
        }, 2000);
      } else {
        // Journey already started, redirect to dashboard
        setTimeout(() => {
          window.location.href = '/index.html';
        }, 2000);
      }
      
      console.log('Onboarding completed successfully');
    } else {
      throw new Error(data.error || 'Onboarding submission failed');
    }
    
  } catch (error) {
    console.error('Onboarding completion error:', error);
    showNotification('Failed to complete onboarding: ' + error.message, 'error');
  }
}

// Start career journey after onboarding
async function startCareerJourney() {
  const authToken = localStorage.getItem('auth_token');
  const currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
  const API_URL = window.location.hostname === 'localhost' ? 'http://localhost:8000' : window.location.origin;
  
  try {
    const goal = onboardingData.step1.dreamJob || onboardingData.step1.currentRole || 'Software Developer';
    
    const response = await fetch(`${API_URL}/agent/start-journey`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        goal: goal,
        user_id: currentUser.id,
        jd_text: null
      })
    });
    
    const data = await response.json();
    
    if (data.session_id) {
      // Store session ID
      localStorage.setItem('current_session_id', data.session_id);
      localStorage.setItem('target_role', data.target_role);
      
      // Redirect to dashboard
      showNotification('Learning journey started!', 'success');
      setTimeout(() => {
        window.location.href = '/index.html';
      }, 1500);
    } else {
      throw new Error('Failed to start journey');
    }
    
  } catch (error) {
    console.error('Journey start error:', error);
    showNotification('Failed to start journey. You can start it manually from the dashboard.', 'error');
    // Still redirect to dashboard
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
  }
}

// Prepare summary for modal
function prepareSummary() {
  // Career goal
  const careerGoal = onboardingData.step1.dreamJob || 'Not specified';
  document.getElementById('summaryCareerGoal').textContent = careerGoal;
  
  // Interests
  const interests = onboardingData.step2.interests.slice(0, 3).join(', ') || 'Not specified';
  document.getElementById('summaryInterests').textContent = interests;
  
  // Skills
  const skills = onboardingData.step3.skills.slice(0, 3).map(s => s.skill).join(', ') || 'Not specified';
  document.getElementById('summarySkills').textContent = skills;
  
  // Learning style
  const learningStyle = onboardingData.step4.learningStyle || 'Not specified';
  const styleLabels = {
    'visual': 'Visual Learner',
    'auditory': 'Auditory Learner',
    'kinesthetic': 'Hands-on Learner',
    'reading': 'Reading/Writing Learner',
    'mixed': 'Mixed Learning Style'
  };
  document.getElementById('summaryLearningStyle').textContent = styleLabels[learningStyle] || learningStyle;
}

// Show success modal
function showSuccessModal() {
  const modal = document.getElementById('successModal');
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
}

// Close success modal
function closeSuccessModal() {
  const modal = document.getElementById('successModal');
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}

// Skip onboarding
function skipOnboarding() {
  if (confirm('Skip onboarding? You can always complete it later from your profile settings.')) {
    localStorage.setItem('onboardingSkipped', 'true');
    window.location.href = 'dashboard.html';
  }
}

// Go back (to previous page)
function goBack() {
  if (document.referrer) {
    window.history.back();
  } else {
    window.location.href = 'index.html';
  }
}

// Toggle theme
function toggleTheme() {
  document.body.classList.toggle('dark');
  const icon = document.querySelector('.theme-toggle .material-icons');
  const isDark = document.body.classList.contains('dark');
  
  icon.textContent = isDark ? 'light_mode' : 'dark_mode';
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  // Show theme change notification
  showNotification(isDark ? 'Dark mode enabled' : 'Light mode enabled');
}

// Show notification
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  
  notification.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: var(--card-light);
    color: var(--text-light);
    padding: 12px 24px;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-lg);
    z-index: 1000;
    animation: slideInUp 0.3s ease;
    border-left: 4px solid var(--primary);
  `;
  
  if (type === 'success') {
    notification.style.borderLeftColor = 'var(--success)';
  } else if (type === 'error') {
    notification.style.borderLeftColor = 'var(--error)';
  }
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOutDown 0.3s ease';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Add CSS animations
function addAnimations() {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    @keyframes slideInRight {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    
    @keyframes slideOutRight {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(100%);
        opacity: 0;
      }
    }
    
    @keyframes slideInUp {
      from {
        transform: translateY(100%);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    
    @keyframes slideOutDown {
      from {
        transform: translateY(0);
        opacity: 1;
      }
      to {
        transform: translateY(100%);
        opacity: 0;
      }
    }
    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
      20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
    
    @keyframes tagAppear {
      from {
        opacity: 0;
        transform: scale(0.8);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
    
    .step-content {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
    
    .step-content.active {
      opacity: 1;
      transform: translateY(0);
    }
    
    .step-content.hidden {
      display: none;
    }
    
    .saved-status.saved {
      animation: pulse 1s ease;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    
    .form-group.focused label {
      color: var(--primary) !important;
    }
    
    .card.selected .card-content {
      border-color: var(--primary) !important;
      background: rgba(33, 150, 243, 0.05) !important;
    }
    
    body.dark .card.selected .card-content {
      background: rgba(33, 150, 243, 0.1) !important;
    }
  `;
  document.head.appendChild(style);
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM loaded, initializing...');
  
  // Add animations
  addAnimations();
  
  // Initialize onboarding
  initOnboarding();
  
  // Load theme preference
  const savedTheme = localStorage.getItem('theme') || 'light';
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    const icon = document.querySelector('.theme-toggle .material-icons');
    if (icon) icon.textContent = 'light_mode';
  }
  
  // Keyboard shortcuts
  document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + Enter to proceed
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      goToNextStep();
    }
    
    // Escape to go back
    if (e.key === 'Escape' && currentStep > 1) {
      goToPreviousStep();
    }
    
    // Number keys 1-4 to navigate
    if (e.key >= '1' && e.key <= '4') {
      const stepNumber = parseInt(e.key);
      if (stepNumber <= currentStep) {
        showStep(stepNumber);
      }
    }
  });
  
  console.log('Initialization complete');
});

// Make functions globally available
window.addInterest = addInterest;
window.addSkill = addSkill;
window.removeInterest = removeInterest;
window.removeSkill = removeSkill;
window.toggleTheme = toggleTheme;
window.goBack = goBack;
window.skipOnboarding = skipOnboarding;
window.startCareerJourney = startCareerJourney;