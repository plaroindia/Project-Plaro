/**
 * Global Error Handler - Catches and logs all JavaScript errors
 * This helps identify what's breaking the app
 */

window.addEventListener('error', function(event) {
    console.error('[GLOBAL ERROR]', {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: event.error
    });
    
    // Don't break the app, just log
    return true;
});

window.addEventListener('unhandledrejection', function(event) {
    console.error('[UNHANDLED PROMISE REJECTION]', event.reason);
    // Don't break the app
    event.preventDefault();
});

// Log when scripts load
console.log('[SCRIPTS] All scripts loading...');
