/**
 * PEARL Agent Backend Integration Module
 * Bridges Pearl Frontend (Pearl/index.html) with FastAPI Backend
 * 
 * Usage: Include this in all Pearl HTML files
 * <script src="js/backend-integration.js"></script>
 */

class PEARLBackendIntegration {
    constructor() {
        // API Configuration
        this.API_URL = window.location.hostname === 'localhost'
            ? 'http://localhost:8000'
            : window.location.origin;
        
        this.authToken = localStorage.getItem('auth_token');
        this.currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
        
        console.log('[PEARL] Backend Integration initialized');
        console.log('[PEARL] API URL:', this.API_URL);
    }

    /**
     * Make authenticated API call to backend
     * @param {string} endpoint - API endpoint path (e.g., '/agent/jobs/recommendations')
     * @param {object} options - Fetch options (method, body, etc)
     * @returns {Promise} Response data
     */
    async apiCall(endpoint, options = {}) {
        const url = `${this.API_URL}${endpoint}`;
        
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };
        
        // Add auth token if available
        if (this.authToken && !options.skipAuth) {
            headers['Authorization'] = `Bearer ${this.authToken}`;
        }
        
        const config = {
            method: options.method || 'GET',
            headers,
            ...options
        };
        
        if (options.body && typeof options.body === 'object') {
            config.body = JSON.stringify(options.body);
        }
        
        try {
            console.log(`[API] ${config.method} ${endpoint}`);
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log(`[API] Response:`, data);
            return data;
            
        } catch (error) {
            console.error(`[API] Error on ${endpoint}:`, error);
            throw error;
        }
    }

    // ============================================
    // AUTHENTICATION ENDPOINTS
    // ============================================

    async signUp(username, email, password) {
        return this.apiCall('/auth/signup', {
            method: 'POST',
            body: { username, email, password },
            skipAuth: true
        });
    }

    async signIn(email, password) {
        return this.apiCall('/auth/signin', {
            method: 'POST',
            body: { email, password },
            skipAuth: true
        });
    }

    async signOut() {
        return this.apiCall('/auth/signout', { method: 'POST' });
    }

    // ============================================
    // JOB RECOMMENDATIONS
    // ============================================

    async getJobRecommendations(userId, targetRole, location) {
        return this.apiCall('/agent/jobs/recommendations', {
            method: 'GET',
        }).then(data => {
            // If you need to pass params in query string:
            // Use: /agent/jobs/recommendations?user_id=${userId}&target_role=${targetRole}&location=${location}
            return data;
        });
    }

    async searchJobs(query, location = '', jobType = '') {
        const params = new URLSearchParams({
            q: query,
            ...(location && { location }),
            ...(jobType && { type: jobType })
        });
        
        return this.apiCall(`/agent/jobs/search?${params}`, { method: 'GET' });
    }

    // ============================================
    // LEARNING PATHS & MODULES
    // ============================================

    async generateLearningPath(jobDescription, skills) {
        return this.apiCall('/agent/learning/generate', {
            method: 'POST',
            body: { job_description: jobDescription, skills }
        });
    }

    async getSession(sessionId) {
        return this.apiCall(`/api/learning/session/${sessionId}`, { method: 'GET' });
    }

    async getModule(sessionId, moduleId) {
        return this.apiCall(`/agent/module/${moduleId}`, { method: 'GET' });
    }

    async completeModule(sessionId, moduleId) {
        return this.apiCall(`/agent/module/${moduleId}/complete`, { method: 'POST' });
    }

    // ============================================
    // GAMIFICATION
    // ============================================

    async getUserPoints(userId) {
        return this.apiCall(`/api/user/${userId}/points`, { method: 'GET' });
    }

    async getLeaderboard(limit = 10) {
        return this.apiCall(`/api/leaderboard?limit=${limit}`, { method: 'GET' });
    }

    async claimDailyRewards() {
        return this.apiCall('/api/rewards/daily-claim', { method: 'POST' });
    }

    async getAchievements(userId) {
        return this.apiCall(`/api/user/${userId}/achievements`, { method: 'GET' });
    }

    // ============================================
    // USER PROFILE & ONBOARDING
    // ============================================

    async completeOnboarding(onboardingData) {
        return this.apiCall('/api/onboarding/complete', {
            method: 'POST',
            body: onboardingData
        });
    }

    async getUserProfile(userId) {
        return this.apiCall(`/api/user/${userId}/profile`, { method: 'GET' });
    }

    async getOnboardingData(userId) {
        return this.apiCall(`/agent/onboarding/${userId}`, { method: 'GET' });
    }

    async updateUserProfile(userId, profileData) {
        return this.apiCall(`/api/user/${userId}/profile`, {
            method: 'PUT',
            body: profileData
        });
    }

    async getUserSkills(userId) {
        return this.apiCall(`/api/user/${userId}/skills`, { method: 'GET' });
    }

    async addUserSkill(userId, skill, proficiency) {
        return this.apiCall(`/api/user/${userId}/skills`, {
            method: 'POST',
            body: { skill, proficiency }
        });
    }

    // ============================================
    // RESUME BUILDER
    // ============================================

    async generateResume(userId, template = 'standard') {
        return this.apiCall('/api/resume/generate', {
            method: 'POST',
            body: { user_id: userId, template }
        });
    }

    async downloadResume(resumeId, format = 'pdf') {
        return this.apiCall(`/api/resume/${resumeId}/download?format=${format}`, {
            method: 'GET'
        });
    }

    // ============================================
    // ANALYTICS
    // ============================================

    async getAnalytics(userId, timeRange = 'week') {
        return this.apiCall(`/api/analytics/${userId}?range=${timeRange}`, {
            method: 'GET'
        });
    }

    async trackEvent(eventType, eventData) {
        return this.apiCall('/api/analytics/track', {
            method: 'POST',
            body: { type: eventType, data: eventData }
        });
    }

    // ============================================
    // CONTENT RECOMMENDATIONS
    // ============================================

    async getContentRecommendations(userId, skillId) {
        return this.apiCall(`/api/content/recommendations?user_id=${userId}&skill_id=${skillId}`, {
            method: 'GET'
        });
    }

    async getCoursesForSkill(skillName) {
        return this.apiCall(`/api/content/courses?skill=${skillName}`, {
            method: 'GET'
        });
    }

    // ============================================
    // UTILITY METHODS
    // ============================================

    /**
     * Check if user is authenticated
     */
    isAuthenticated() {
        return !!this.authToken && !!this.currentUser.id;
    }

    /**
     * Set authentication token
     */
    setAuthToken(token, userData) {
        this.authToken = token;
        this.currentUser = userData;
        localStorage.setItem('auth_token', token);
        localStorage.setItem('user_data', JSON.stringify(userData));
    }

    /**
     * Clear authentication
     */
    clearAuth() {
        this.authToken = null;
        this.currentUser = {};
        localStorage.removeItem('auth_token');
        localStorage.removeItem('user_data');
    }

    /**
     * Get current user
     */
    getCurrentUser() {
        return this.currentUser;
    }

    /**
     * Update current user
     */
    updateCurrentUser(userData) {
        this.currentUser = { ...this.currentUser, ...userData };
        localStorage.setItem('user_data', JSON.stringify(this.currentUser));
    }

    /**
     * Show error toast
     */
    showError(message, title = 'Error') {
        console.error(`[ERROR] ${title}:`, message);
        // Implement your toast notification here
        alert(`${title}: ${message}`);
    }

    /**
     * Show success toast
     */
    showSuccess(message, title = 'Success') {
        console.log(`[SUCCESS] ${title}:`, message);
        // Implement your toast notification here
        alert(`${title}: ${message}`);
    }
}

// Global instance
const pearl = new PEARLBackendIntegration();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PEARLBackendIntegration;
}
