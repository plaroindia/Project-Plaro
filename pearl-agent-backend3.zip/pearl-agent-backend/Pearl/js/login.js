// Theme Management
function toggleTheme() {
  document.body.classList.toggle('dark');
  const icon = document.querySelector('.theme-toggle .material-icons');
  const isDark = document.body.classList.contains('dark');
  icon.textContent = isDark ? 'light_mode' : 'dark_mode';
  
  // Save theme preference
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  showSnackbar(isDark ? 'Dark mode enabled' : 'Light mode enabled', 'success');
}

function loadTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    const icon = document.querySelector('.theme-toggle .material-icons');
    icon.textContent = 'light_mode';
  }
}

// Navigation
function goBack() {
  if (document.referrer) {
    window.history.back();
  } else {
    window.location.href = 'index.html';
  }
}

// Password Visibility Toggle
function togglePassword(fieldId) {
  const field = document.getElementById(fieldId);
  const icon = field.nextElementSibling;
  
  if (field.type === 'password') {
    field.type = 'text';
    icon.textContent = 'visibility';
    icon.style.color = 'var(--primary)';
  } else {
    field.type = 'password';
    icon.textContent = 'visibility_off';
    icon.style.color = '';
  }
}

// Form Validation
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function showError(fieldId, message) {
  const errorElement = document.getElementById(fieldId);
  errorElement.textContent = message;
  errorElement.style.display = 'flex';
}

function clearError(fieldId) {
  const errorElement = document.getElementById(fieldId);
  errorElement.textContent = '';
  errorElement.style.display = 'none';
}

function validateForm() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  
  let isValid = true;
  
  // Validate email
  if (!email) {
    showError('emailError', 'Please enter your email address');
    isValid = false;
  } else if (!validateEmail(email)) {
    showError('emailError', 'Please enter a valid email address');
    isValid = false;
  } else {
    clearError('emailError');
  }
  
  // Validate password
  if (!password) {
    showError('passwordError', 'Please enter your password');
    isValid = false;
  } else if (password.length < 6) {
    showError('passwordError', 'Password must be at least 6 characters');
    isValid = false;
  } else {
    clearError('passwordError');
  }
  
  return isValid;
}

// Snackbar Notification
function showSnackbar(message, type = 'success') {
  const snackbar = document.getElementById('snackbar');
  snackbar.textContent = message;
  snackbar.className = `snackbar ${type}`;
  
  snackbar.classList.add('show');
  
  setTimeout(() => {
    snackbar.classList.remove('show');
  }, 3000);
}

// Social Login
function socialLogin(provider) {
  showSnackbar(`Signing in with ${provider}...`, 'warning');
  // In a real application, this would redirect to OAuth provider
  // setTimeout(() => {
  //   window.location.href = `/auth/${provider}`;
  // }, 1000);
}

// Form Submission
document.getElementById('loginForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  if (!validateForm()) {
    return;
  }
  
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const remember = document.getElementById('remember').checked;
  
  // Show loading state
  const submitBtn = this.querySelector('button[type="submit"]');
  const originalText = submitBtn.textContent;
  submitBtn.textContent = 'Signing In...';
  submitBtn.disabled = true;
  
  try {
    // Call backend API to signin
    const response = await pearl.signIn(email, password);
    
    // Check if signin was successful
    if (response.success === false || !response.access_token) {
      throw new Error(response.error || response.detail || 'Invalid email or password');
    }
    
    // Save authentication data
    pearl.setAuthToken(response.access_token, {
      id: response.user.id,
      email: response.user.email,
      username: response.user.username
    });
    
    // Save login state if remember me is checked
    if (remember) {
      localStorage.setItem('rememberLogin', 'true');
      localStorage.setItem('userEmail', email);
    } else {
      localStorage.removeItem('rememberLogin');
      localStorage.removeItem('userEmail');
    }
    
    showSnackbar('Login successful! Redirecting...', 'success');
    
    // Redirect to dashboard or onboarding based on requirements
    const redirectPath = response.requires_onboarding ? 'onboarding.html' : 'index.html';
    setTimeout(() => {
      window.location.href = redirectPath;
    }, 1500);
    
  } catch (error) {
    console.error('[LOGIN] Error:', error);
    showSnackbar(error.message || 'Login failed. Please check your credentials.', 'error');
    
    // Shake animation on error
    const form = document.getElementById('loginForm');
    form.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
      form.style.animation = '';
    }, 500);
  } finally {
    // Reset button state
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  }
});

// Load saved email if "Remember me" was checked
function loadSavedEmail() {
  const rememberLogin = localStorage.getItem('rememberLogin');
  const savedEmail = localStorage.getItem('userEmail');
  
  if (rememberLogin === 'true' && savedEmail) {
    document.getElementById('email').value = savedEmail;
    document.getElementById('remember').checked = true;
  }
}

// Add shake animation
const style = document.createElement('style');
style.textContent = `
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
    20%, 40%, 60%, 80% { transform: translateX(5px); }
  }
`;
document.head.appendChild(style);

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  loadTheme();
  loadSavedEmail();
  
  // Real-time validation
  document.getElementById('email').addEventListener('input', function() {
    const email = this.value.trim();
    if (email && !validateEmail(email)) {
      showError('emailError', 'Please enter a valid email');
    } else {
      clearError('emailError');
    }
  });
  
  document.getElementById('password').addEventListener('input', function() {
    if (this.value.length > 0 && this.value.length < 6) {
      showError('passwordError', 'Password must be at least 6 characters');
    } else {
      clearError('passwordError');
    }
  });
  
  // Add keyboard shortcuts
  document.addEventListener('keydown', function(e) {
    // Ctrl + Enter to submit form
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      document.getElementById('loginForm').dispatchEvent(new Event('submit'));
    }
    
    // Alt + E to focus email
    if (e.altKey && e.key === 'e') {
      e.preventDefault();
      document.getElementById('email').focus();
    }
    
    // Alt + P to focus password
    if (e.altKey && e.key === 'p') {
      e.preventDefault();
      document.getElementById('password').focus();
    }
  });
  
  // Auto-focus email field on page load
  document.getElementById('email').focus();
});