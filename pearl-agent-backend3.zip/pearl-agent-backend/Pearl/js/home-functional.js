/**
 * Pearl Frontend - Fully Functional Home Page
 * Integrated with Backend API
 */

// Auth State
let authToken = localStorage.getItem('auth_token');
let currentUser = JSON.parse(localStorage.getItem('user_data') || '{}');
const API_URL = window.location.hostname === 'localhost' ? 'http://localhost:8000' : window.location.origin;

// DOM Elements
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileMenuClose = document.querySelector('.mobile-menu-close');
const moduleCards = document.querySelectorAll('.module-card');
const applyButtons = document.querySelectorAll('.apply-btn');
const filterButtons = document.querySelectorAll('.filter-btn');
const moduleModal = document.querySelector('.module-modal');
const storyModal = document.querySelector('.story-modal');
const modalClose = document.querySelectorAll('.modal-close');
const storyClose = document.querySelector('.story-close');
const snackbar = document.querySelector('.snackbar');
const themeToggle = document.getElementById('themeToggle');
const mobileThemeToggle = document.getElementById('mobileThemeToggle');
const taikenPreview = document.querySelector('.taiken-preview');
const enterStoryBtn = document.getElementById('enterStoryBtn');
const continueBtn = document.getElementById('continueBtn');
const userMenu = document.querySelector('.user-menu');
const userDropdown = document.querySelector('.user-dropdown');

// ============================================
// API FUNCTIONS
// ============================================

async function apiCall(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (authToken && !options.skipAuth) {
        headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    const config = {
        method: options.method || 'GET',
        headers,
        ...options
    };
    
    if (options.body && typeof options.body === 'object') {
        config.body = JSON.stringify(options.body);
    }
    
    try {
        const response = await fetch(url, config);
        
        if (response.status === 401) {
            clearAuth();
            window.location.href = '/login.html';
            throw new Error('Session expired');
        }
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.detail || errorData.error || `HTTP ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error(`[API] Error:`, error);
        throw error;
    }
}

function clearAuth() {
    authToken = null;
    currentUser = null;
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
}

// ============================================
// MODULE DATA
// ============================================

const moduleData = {
    'web-fundamentals': {
        title: 'Web Fundamentals',
        description: 'Master HTML5, CSS3, and responsive design.',
        progress: 100,
        curriculum: [
            { title: 'HTML5 Semantic Elements', status: 'completed' },
            { title: 'CSS3 Styling & Layout', status: 'completed' },
            { title: 'Responsive Design', status: 'completed' }
        ]
    },
    'javascript-basics': {
        title: 'JavaScript Core',
        description: 'Learn JavaScript fundamentals and ES6+.',
        progress: 100,
        curriculum: [
            { title: 'Variables & Data Types', status: 'completed' },
            { title: 'Functions & Scope', status: 'completed' },
            { title: 'DOM Manipulation', status: 'completed' }
        ]
    },
    'react-mastery': {
        title: 'React Framework',
        description: 'Master React.js and build interactive applications.',
        progress: 0,
        curriculum: [
            { title: 'React Components', status: 'upcoming' },
            { title: 'React Hooks', status: 'upcoming' },
            { title: 'State Management', status: 'upcoming' }
        ]
    },
    'taiken-story': {
        title: 'Taiken Story Lab',
        description: 'Apply skills through immersive learning experiences.',
        progress: 45,
        currentStory: {
            title: 'The Startup Challenge',
            chapter: 'Chapter 2: The Bug Hunt',
            description: 'Debug production issues and implement fixes.',
            skills: ['Debugging', 'JavaScript', 'Problem Solving']
        }
    }
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    initMobileMenu();
    initModuleInteractions();
    initJobApplications();
    initFilters();
    initThemeToggle();
    initAnimations();
    initUserMenu();
    loadDashboard();
    
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark');
        if (themeToggle) themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
});

// ============================================
// AUTH FUNCTIONS
// ============================================

function checkAuthStatus() {
    if (!authToken || !currentUser.id) {
        window.location.href = '/login.html';
    }
}

function initUserMenu() {
    if (!userMenu) return;
    
    userMenu.addEventListener('click', () => {
        if (userDropdown) {
            userDropdown.classList.toggle('active');
        }
    });
    
    // Update user info in navbar
    const userNameEl = document.querySelector('.user-name');
    if (userNameEl && currentUser.username) {
        userNameEl.textContent = currentUser.username;
    }
}

function signOut() {
    clearAuth();
    showNotification('Signed out successfully', 'success');
    setTimeout(() => {
        window.location.href = '/login.html';
    }, 1000);
}

// ============================================
// DASHBOARD FUNCTIONS
// ============================================

async function loadDashboard() {
    try {
        // Load quick stats
        const [points, skills, jobs] = await Promise.all([
            apiCall(`/api/user/${currentUser.id}/points`).catch(() => ({ total: 0, streak: 0 })),
            apiCall(`/api/user/${currentUser.id}/skills`).catch(() => []),
            apiCall(`/agent/jobs/recommendations`).catch(() => [])
        ]);
        
        updateDashboardStats(points, skills.length);
        displayJobs(jobs);
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

function updateDashboardStats(points, skillCount) {
    const pointsEl = document.querySelector('.quick-stat:nth-child(1) .stat-value');
    const skillsEl = document.querySelector('.quick-stat:nth-child(2) .stat-value');
    
    if (pointsEl) pointsEl.textContent = points?.total || 0;
    if (skillsEl) skillsEl.textContent = skillCount;
}

async function displayJobs(jobs) {
    if (!jobs || jobs.length === 0) return;
    
    const jobsContainer = document.querySelector('.jobs-grid');
    if (!jobsContainer) return;
    
    jobsContainer.innerHTML = jobs.map(job => `
        <div class="job-card">
            <div class="job-header">
                <h3>${job.title || 'Job Title'}</h3>
                <span class="match-badge">${job.match_score || 85}%</span>
            </div>
            <p class="company">${job.company || 'Company'}</p>
            <p class="location">${job.location || 'Location'}</p>
            <div class="job-meta">
                <span>${job.type || 'Full-time'}</span>
                <span>${job.salary || 'Competitive'}</span>
            </div>
            <button class="apply-btn primary" onclick="applyForJob('${job.id}', '${job.title}')">
                <i class="fas fa-arrow-right"></i> Apply
            </button>
        </div>
    `).join('');
}

async function applyForJob(jobId, jobTitle) {
    try {
        const btn = event.target.closest('.apply-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Applying...';
        
        // Track the application
        await apiCall('/api/analytics/track', {
            method: 'POST',
            body: { event_type: 'job_applied', job_id: jobId }
        });
        
        btn.innerHTML = '<i class="fas fa-check"></i> Applied';
        showNotification(`Applied for ${jobTitle}!`, 'success');
    } catch (error) {
        showNotification('Failed to apply for job', 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> Apply';
    }
}

// ============================================
// MODULE FUNCTIONS
// ============================================

function initModuleInteractions() {
    moduleCards.forEach(card => {
        if (!card.classList.contains('locked')) {
            card.addEventListener('click', (e) => {
                const moduleId = card.getAttribute('data-module');
                if (moduleId && moduleData[moduleId]) {
                    if (moduleId === 'taiken-story') {
                        openStoryModal(moduleId);
                    } else {
                        openModuleModal(moduleId);
                    }
                }
            });
        }
    });
    
    modalClose.forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            closeModuleModal();
            closeStoryModal();
        });
    });
    
    if (storyClose) {
        storyClose.addEventListener('click', closeStoryModal);
    }
    
    moduleModal.addEventListener('click', (e) => {
        if (e.target === moduleModal) closeModuleModal();
    });
    
    storyModal.addEventListener('click', (e) => {
        if (e.target === storyModal) closeStoryModal();
    });
}

function openModuleModal(moduleId) {
    const data = moduleData[moduleId];
    if (!data) return;
    
    document.getElementById('modalTitle').textContent = data.title;
    document.getElementById('modalDescription').textContent = data.description;
    document.getElementById('modalProgress').textContent = data.progress + '%';
    document.getElementById('modalProgressBar').style.width = data.progress + '%';
    
    const curriculumList = document.getElementById('modalCurriculum');
    curriculumList.innerHTML = data.curriculum?.map(item => `
        <div class="curriculum-item ${item.status}">
            <i class="fas ${item.status === 'completed' ? 'fa-check' : 'fa-circle'}"></i>
            <span>${item.title}</span>
        </div>
    `).join('') || '';
    
    moduleModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModuleModal() {
    moduleModal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

function openStoryModal(moduleId) {
    const data = moduleData[moduleId];
    if (!data) return;
    
    document.getElementById('storyProgress').textContent = data.progress + '%';
    document.getElementById('storyProgressBar').style.width = data.progress + '%';
    
    storyModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeStoryModal() {
    storyModal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// ============================================
// UI FUNCTIONS
// ============================================

function initMobileMenu() {
    if (!mobileMenuBtn) return;
    
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    mobileMenuClose.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
    });
}

function initThemeToggle() {
    if (!themeToggle) return;
    
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark');
        localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
        themeToggle.innerHTML = document.body.classList.contains('dark') ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    });
}

function initJobApplications() {
    // Jobs are loaded dynamically
}

function initFilters() {
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            filterJobs(this.textContent);
        });
    });
}

function filterJobs(filter) {
    const jobCards = document.querySelectorAll('.job-card');
    jobCards.forEach(card => {
        let show = true;
        
        if (filter === 'Remote') {
            show = card.querySelector('.location').textContent.includes('Remote');
        } else if (filter === 'Full-time') {
            show = card.querySelector('.job-meta').textContent.includes('Full-time');
        } else if (filter === 'High Match') {
            const score = parseInt(card.querySelector('.match-badge').textContent);
            show = score >= 90;
        }
        
        card.style.display = show ? 'block' : 'none';
    });
}

function initAnimations() {
    const progressCircles = document.querySelectorAll('.progress-circle');
    progressCircles.forEach(circle => {
        const progress = parseInt(circle.getAttribute('data-progress') || 0);
        const fill = circle.querySelector('.progress-fill');
        const radius = 45;
        const circumference = 2 * Math.PI * radius;
        
        if (fill) {
            fill.style.strokeDasharray = circumference;
            fill.style.strokeDashoffset = circumference - (progress / 100) * circumference;
        }
    });
}

function showNotification(message, type = 'success') {
    if (!snackbar) return;
    
    const snackbarContent = snackbar.querySelector('.snackbar-content');
    if (!snackbarContent) return;
    
    const icon = snackbarContent.querySelector('i');
    if (icon) {
        icon.className = type === 'error' ? 'fas fa-exclamation-circle' : 
                        type === 'info' ? 'fas fa-info-circle' : 'fas fa-check-circle';
    }
    
    const span = snackbarContent.querySelector('span');
    if (span) span.textContent = message;
    
    snackbar.classList.add('show');
    setTimeout(() => {
        snackbar.classList.remove('show');
    }, 3000);
}

// Navbar user menu interaction
document.addEventListener('DOMContentLoaded', () => {
    const userMenu = document.querySelector('.user-menu');
    if (userMenu) {
        userMenu.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = userMenu.querySelector('.user-dropdown');
            if (dropdown) {
                dropdown.classList.toggle('active');
            }
        });
    }
});
